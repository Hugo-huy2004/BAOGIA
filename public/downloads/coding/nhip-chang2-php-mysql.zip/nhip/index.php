<?php
declare(strict_types=1);

require __DIR__ . '/includes/bootstrap.php';

const CURRENT_USER_ID = 1;   // tạm là lan.code — step 12 thay bằng người đang đăng nhập

$error = null;
$body = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $body = (string) ($_POST['body'] ?? '');
    $error = check_post($body);
    if ($error === null) {
        create_post(CURRENT_USER_ID, $body);
        redirect('index.php');
    }
}

$posts = feed_posts();
$title = 'Bảng tin';
$active = 'feed';
require __DIR__ . '/includes/header.php';
?>
  <main class="feed">
    <h1 class="visually-hidden">Bảng tin</h1>

    <form class="composer" method="post" action="index.php">
      <label for="body">Có gì mới?</label>
      <textarea id="body" name="body" rows="3" maxlength="<?= MAX_LENGTH ?>" required
                placeholder="Bạn đang nghĩ gì?"><?= e($body) ?></textarea>
      <?php if ($error !== null): ?>
        <p class="form-error" role="alert"><?= e($error) ?></p>
      <?php endif; ?>
      <div class="composer-foot">
        <span><?= MAX_LENGTH ?> ký tự</span>
        <button type="submit">Đăng</button>
      </div>
    </form>

    <section aria-label="Bài mới nhất" id="posts">
      <?php foreach ($posts as $post): ?>
        <?php require __DIR__ . '/includes/post.php'; ?>
      <?php endforeach; ?>
      <?php if (!$posts): ?>
        <p class="empty">Chưa có bài nào. Hãy là người đầu tiên!</p>
      <?php endif; ?>
    </section>
  </main>
<?php require __DIR__ . '/includes/footer.php'; ?>
