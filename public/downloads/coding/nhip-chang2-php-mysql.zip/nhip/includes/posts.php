<?php
declare(strict_types=1);

// Mọi câu SQL về bài đăng nằm ở đây. Trang PHP chỉ gọi hàm, không viết SQL.

const FEED_SQL = '
    SELECT p.id, p.user_id, p.body, p.created_at, u.username, u.display_name, u.avatar,
           COUNT(l.user_id) AS likes
    FROM posts AS p
    JOIN users AS u ON u.id = p.user_id
    LEFT JOIN likes AS l ON l.post_id = p.id';

/** 20 bài gốc mới nhất cho bảng tin. */
function feed_posts(int $limit = 20): array
{
    $stmt = db()->prepare(FEED_SQL . '
        WHERE p.parent_id IS NULL
        GROUP BY p.id
        ORDER BY p.created_at DESC, p.id DESC
        LIMIT :limit');
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

/** Bài gốc của một người dùng, cho trang cá nhân. */
function posts_by_user(int $userId): array
{
    $stmt = db()->prepare(FEED_SQL . '
        WHERE p.parent_id IS NULL AND p.user_id = :user_id
        GROUP BY p.id
        ORDER BY p.created_at DESC, p.id DESC');
    $stmt->execute(['user_id' => $userId]);
    return $stmt->fetchAll();
}

/** Thêm bài, trả id của bài mới. */
function create_post(int $userId, string $body): int
{
    $stmt = db()->prepare('INSERT INTO posts (user_id, body) VALUES (:user_id, :body)');
    $stmt->execute(['user_id' => $userId, 'body' => trim($body)]);
    return (int) db()->lastInsertId();
}
