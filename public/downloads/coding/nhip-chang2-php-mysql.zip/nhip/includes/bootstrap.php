<?php
declare(strict_types=1);

// Mọi trang chỉ cần require tệp này một lần.
require __DIR__ . '/helpers.php';
require __DIR__ . '/db.php';
require __DIR__ . '/posts.php';
require __DIR__ . '/users.php';

$config = require __DIR__ . '/config.php';
ini_set('display_errors', $config['debug'] ? '1' : '0');
error_reporting(E_ALL);
