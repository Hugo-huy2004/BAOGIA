<?php
declare(strict_types=1);

/** Một người dùng theo tên, kèm số người theo dõi / đang theo dõi. null nếu không có. */
function find_user_by_username(string $username): ?array
{
    $stmt = db()->prepare('
        SELECT u.id, u.username, u.display_name, u.bio, u.avatar, u.created_at,
               (SELECT COUNT(*) FROM follows WHERE followee_id = u.id) AS followers,
               (SELECT COUNT(*) FROM follows WHERE follower_id = u.id) AS following
        FROM users AS u
        WHERE u.username = ?');
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    return $user === false ? null : $user;
}
