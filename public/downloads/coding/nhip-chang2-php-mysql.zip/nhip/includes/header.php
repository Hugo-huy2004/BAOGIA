<?php
/** @var string $title  tiêu đề trang
 *  @var string $active trang đang mở: 'feed' | 'profile' */
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($title) ?> · Nhịp</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <header class="topbar">
    <a href="index.php" class="logo">Nhịp</a>
    <nav aria-label="Điều hướng chính">
      <a href="index.php" <?= $active === 'feed' ? 'aria-current="page"' : '' ?>>Bảng tin</a>
      <a href="profile.php?u=lan.code" <?= $active === 'profile' ? 'aria-current="page"' : '' ?>>Trang cá nhân</a>
    </nav>
  </header>
