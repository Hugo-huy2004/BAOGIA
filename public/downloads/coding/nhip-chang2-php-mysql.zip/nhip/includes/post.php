<?php /** @var array $post một dòng từ FEED_SQL */ ?>
<article class="post">
  <img class="avatar" src="<?= e($post['avatar'] ?? 'img/avatar.svg') ?>" alt="" width="40" height="40">
  <div class="post-body">
    <header class="post-head">
      <a class="author" href="profile.php?u=<?= urlencode($post['username']) ?>">
        <?= e($post['display_name']) ?> <span class="handle">@<?= e($post['username']) ?></span>
      </a>
      <time datetime="<?= e($post['created_at']) ?>"><?= time_ago($post['created_at']) ?></time>
    </header>
    <p class="post-text"><?= e($post['body']) ?></p>
    <footer class="post-actions">
      <span class="like-count">♥ <?= (int) $post['likes'] ?></span>
    </footer>
  </div>
</article>
