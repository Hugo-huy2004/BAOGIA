<?php
declare(strict_types=1);

date_default_timezone_set('Asia/Ho_Chi_Minh');

const MAX_LENGTH = 500;

/** In chữ ra HTML an toàn: < > & " ' thành thực thể, không bao giờ chạy như mã. */
function e(?string $text): string
{
    return htmlspecialchars($text ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** "3 phút trước", "2 giờ trước" — cùng ý với timeAgo() ở chặng 1. */
function time_ago(string $datetime): string
{
    $seconds = time() - strtotime($datetime);
    if ($seconds < 60) {
        return 'vừa xong';
    }
    if ($seconds < 3600) {
        return intdiv($seconds, 60) . ' phút trước';
    }
    if ($seconds < 86400) {
        return intdiv($seconds, 3600) . ' giờ trước';
    }
    return date('d/m/Y', strtotime($datetime));
}

/** Kiểm tra nội dung bài: trả chuỗi lỗi, hoặc null nếu hợp lệ. */
function check_post(string $body): ?string
{
    $body = trim($body);
    if ($body === '') {
        return 'Hãy viết gì đó.';
    }
    if (mb_strlen($body) > MAX_LENGTH) {
        return 'Tối đa ' . MAX_LENGTH . ' ký tự.';
    }
    return null;
}

/** Chuyển hướng rồi dừng hẳn — không để mã phía dưới chạy tiếp. */
function redirect(string $url): never
{
    header('Location: ' . $url, true, 303);
    exit;
}
