const ME = "lan.code";

const posts = [
  { id: 1, author: "lan.code", text: "Hôm nay mình bắt đầu học Coding!", createdAt: "2026-10-27T08:00:00", likes: 3, likedByMe: false },
  { id: 2, author: "minh.dev", text: "CSS flexbox cứu cả buổi chiều.", createdAt: "2026-10-27T09:10:00", likes: 5, likedByMe: true },
  { id: 3, author: "lan.code", text: "Box model: content, padding, border, margin.", createdAt: "2026-10-27T09:45:00", likes: 1, likedByMe: false },
];

function newestFirst(list) {
  return [...list].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

function postsBy(list, author) {
  return list.filter((post) => post.author === author);
}

function totalLikes(list, author) {
  return postsBy(list, author).reduce((sum, post) => sum + post.likes, 0);
}

console.log(newestFirst(posts).map((p) => p.id));   // [3, 2, 1]
console.log(totalLikes(posts, ME));                 // 4

function toggleLike(list, id) {
  return list.map((post) => {
    if (post.id !== id) return post;
    const likedByMe = !post.likedByMe;
    return { ...post, likedByMe, likes: post.likes + (likedByMe ? 1 : -1) };
  });
}

const after = toggleLike(posts, 1);
console.log(after[0].likes, after[0].likedByMe);   // 4 true
console.log(posts[0].likes);                       // 3 — bản gốc không đổi

const MAX_LENGTH = 500;

function checkPost(text) {
  const clean = text.trim();
  if (clean.length === 0) return "Hãy viết gì đó";
  if (clean.length > MAX_LENGTH) return `Tối đa ${MAX_LENGTH} ký tự`;
  return "ok";
}

function createPost(list, text) {
  const id = Math.max(0, ...list.map((p) => p.id)) + 1;
  const post = { id, author: ME, text: text.trim(), createdAt: new Date().toISOString(), likes: 0, likedByMe: false };
  return [post, ...list];
}

const rtf = new Intl.RelativeTimeFormat("vi", { numeric: "auto" });
function timeAgo(iso) {
  const minutes = Math.round((new Date(iso) - Date.now()) / 60000);
  if (Math.abs(minutes) < 60) return rtf.format(minutes, "minute");
  const hours = Math.round(minutes / 60);
  if (Math.abs(hours) < 24) return rtf.format(hours, "hour");
  return rtf.format(Math.round(hours / 24), "day");
}

console.assert(checkPost("   ") === "Hãy viết gì đó", "chuỗi trắng phải bị chặn");
console.assert(checkPost("a".repeat(500)) === "ok", "đúng 500 ký tự vẫn hợp lệ");
console.assert(checkPost("a".repeat(501)) !== "ok", "501 ký tự phải bị chặn");
console.assert(createPost(posts, "Mới")[0].text === "Mới", "bài mới nằm đầu");
console.assert(posts.length === 3, "createPost không được sửa mảng gốc");
console.assert(toggleLike(toggleLike(posts, 2), 2)[1].likes === 5, "thả rồi bỏ tim về như cũ");

const STORAGE_KEY = "nhip.posts";

function load() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
    return Array.isArray(saved) ? saved : posts;
  } catch {
    return posts;               // dữ liệu hỏng: quay về dữ liệu mẫu
  }
}

let state = load();

function save() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function renderPosts(container, list) {
  const template = document.querySelector("#post-template");
  container.replaceChildren(...list.map((post) => {
    const node = template.content.cloneNode(true);
    node.querySelector("article").dataset.id = post.id;
    node.querySelector(".author").textContent = post.author;
    node.querySelector("time").textContent = timeAgo(post.createdAt);
    node.querySelector("time").dateTime = post.createdAt;
    node.querySelector(".post-text").textContent = post.text;   // KHÔNG innerHTML
    const like = node.querySelector(".like");
    like.setAttribute("aria-pressed", String(post.likedByMe));
    like.setAttribute("aria-label", post.likedByMe ? "Bỏ thích" : "Thích");
    like.querySelector("span").textContent = post.likes;
    return node;
  }));
}

const postsBox = document.querySelector("#posts");
const onProfile = Boolean(document.querySelector(".profile"));

function render() {
  const list = onProfile ? postsBy(state, ME) : state;
  renderPosts(postsBox, newestFirst(list));
}

postsBox.addEventListener("click", (event) => {
  const button = event.target.closest(".like");
  if (!button) return;
  const id = Number(button.closest("article").dataset.id);
  state = toggleLike(state, id);
  save();
  render();
});

render();

const composer = document.querySelector("#composer");

if (composer) {
  const textarea = composer.querySelector("textarea");
  const counter = document.querySelector("#counter");

  textarea.addEventListener("input", () => {
    counter.textContent = `${textarea.value.length}/${MAX_LENGTH}`;
    textarea.setCustomValidity("");
  });

  composer.addEventListener("submit", (event) => {
    event.preventDefault();
    const result = checkPost(textarea.value);
    if (result !== "ok") {
      textarea.setCustomValidity(result);
      textarea.reportValidity();
      return;
    }
    state = createPost(state, textarea.value);
    save();
    render();
    composer.reset();
    counter.textContent = `0/${MAX_LENGTH}`;
  });
}