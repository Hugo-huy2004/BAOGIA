<?php
declare(strict_types=1);

require __DIR__ . '/includes/bootstrap.php';

$user = find_user_by_username((string) ($_GET['u'] ?? ''));
if ($user === null) {
    http_response_code(404);
    $title = 'Không tìm thấy';
    $active = 'profile';
    require __DIR__ . '/includes/header.php';
    echo '<main class="profile"><p class="empty">Không có người dùng này.</p></main>';
    require __DIR__ . '/includes/footer.php';
    exit;
}

$posts = posts_by_user((int) $user['id']);
$me = current_user();
$isMe = $me !== null && (int) $me['id'] === (int) $user['id'];
$following = $me !== null && !$isMe && is_following((int) $me['id'], (int) $user['id']);
$posts = mark_liked($posts, $me);
$title = $user['display_name'];
$active = $isMe ? 'profile' : '';
require __DIR__ . '/includes/header.php';
?>
  <main class="profile">
    <header class="profile-head">
      <div>
        <h1><?= e($user['display_name']) ?></h1>
        <p class="handle">@<?= e($user['username']) ?></p>
        <?php if ($user['bio'] !== ''): ?>
          <p class="bio"><?= e($user['bio']) ?></p>
        <?php endif; ?>
        <p class="stats">
          <strong><?= (int) $user['followers'] ?></strong> người theo dõi ·
          <strong><?= (int) $user['following'] ?></strong> đang theo dõi
        </p>
      </div>
      <img class="avatar-lg" src="<?= e($user['avatar'] ?? 'img/avatar.svg') ?>" alt="" width="72" height="72">
      <?php if ($isMe): ?>
        <a class="follow" href="settings.php">Sửa hồ sơ</a>
      <?php elseif ($me): ?>
        <form method="post" action="follow.php" class="follow-form">
          <input type="hidden" name="user_id" value="<?= (int) $user['id'] ?>">
          <input type="hidden" name="action" value="<?= $following ? 'unfollow' : 'follow' ?>">
          <button type="submit" class="follow <?= $following ? 'is-following' : '' ?>" aria-pressed="<?= $following ? 'true' : 'false' ?>">
            <?= $following ? 'Đang theo dõi' : 'Theo dõi' ?>
          </button>
        </form>
      <?php endif; ?>
    </header>

    <section aria-labelledby="posts-title">
      <h2 id="posts-title">Bài viết</h2>
      <?php foreach ($posts as $post): ?>
        <?php require __DIR__ . '/includes/post.php'; ?>
      <?php endforeach; ?>
    </section>
  </main>
<?php require __DIR__ . '/includes/footer.php'; ?>
