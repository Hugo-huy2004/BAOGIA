<?php
declare(strict_types=1);

require __DIR__ . '/includes/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    abort(405, 'Phương thức không được phép.');
}
$me = require_login();
$target = find_user_by_id(id_param($_POST, 'user_id'));
if ($target === null) {
    abort(404, 'Không có người dùng này.');
}

if (($_POST['action'] ?? '') === 'unfollow') {
    unfollow((int) $me['id'], (int) $target['id']);
} else {
    follow((int) $me['id'], (int) $target['id']);
}
redirect('profile.php?u=' . urlencode($target['username']));
