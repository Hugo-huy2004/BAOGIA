<?php
declare(strict_types=1);

require __DIR__ . '/includes/bootstrap.php';

$me = require_login();
$id = id_param($_GET);
$post = find_post($id);

if ($post === null) {
    abort(404, 'Bài này không còn tồn tại.');
}
if ((int) $post['user_id'] !== (int) $me['id']) {
    abort(403, 'Bạn chỉ sửa được bài của mình.');
}

$body = $post['body'];
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $body = (string) ($_POST['body'] ?? '');
    $error = check_post($body);
    if ($error === null) {
        update_post($id, (int) $me['id'], $body);
        flash('Đã lưu thay đổi.');
        redirect('post.php?id=' . $id);
    }
}

$title = 'Sửa bài';
$active = '';
require __DIR__ . '/includes/header.php';
?>
  <main class="feed">
    <h1>Sửa bài</h1>
    <form class="composer" method="post" action="edit.php?id=<?= $id ?>">
      <label for="body">Nội dung</label>
      <textarea id="body" name="body" rows="5" maxlength="<?= MAX_LENGTH ?>" required><?= e($body) ?></textarea>
      <?php if ($error !== null): ?>
        <p class="form-error" role="alert"><?= e($error) ?></p>
      <?php endif; ?>
      <div class="composer-foot">
        <a href="post.php?id=<?= $id ?>">Huỷ</a>
        <button type="submit">Lưu</button>
      </div>
    </form>
  </main>
<?php require __DIR__ . '/includes/footer.php'; ?>
