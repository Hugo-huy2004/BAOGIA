<?php
declare(strict_types=1);

require __DIR__ . '/includes/bootstrap.php';

if (current_user()) {
    redirect('index.php');
}

$login = '';
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim((string) ($_POST['login'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');
    $userId = verify_login($login, $password);
    if ($userId === null) {
        // Không nói rõ sai tên hay sai mật khẩu.
        $error = 'Tên đăng nhập hoặc mật khẩu không đúng.';
    } else {
        login_user($userId);
        redirect('index.php');
    }
}

$title = 'Đăng nhập';
$active = 'login';
require __DIR__ . '/includes/header.php';
?>
  <main class="auth">
    <h1>Đăng nhập</h1>
    <form method="post" action="login.php">
      <div class="field">
        <label for="login">Tên người dùng hoặc email</label>
        <input id="login" name="login" value="<?= e($login) ?>" required autocomplete="username">
      </div>
      <div class="field">
        <label for="password">Mật khẩu</label>
        <input id="password" name="password" type="password" required autocomplete="current-password">
      </div>
      <?php if ($error): ?>
        <p class="form-error" role="alert"><?= e($error) ?></p>
      <?php endif; ?>
      <button type="submit" class="primary">Đăng nhập</button>
    </form>
    <p>Chưa có tài khoản? <a href="register.php">Đăng ký</a></p>
  </main>
<?php require __DIR__ . '/includes/footer.php'; ?>
