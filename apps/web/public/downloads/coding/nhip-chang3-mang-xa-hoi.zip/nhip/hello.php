<?php
// Tệp PHP đầu tiên: máy chủ chạy đoạn này rồi chỉ gửi KẾT QUẢ về trình duyệt.
date_default_timezone_set('Asia/Ho_Chi_Minh');

$name = 'Nhịp';
$time = date('H:i, d/m/Y');
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <title>Xin chào từ PHP</title>
</head>
<body>
  <h1>Xin chào, <?= $name ?>!</h1>
  <p>Máy chủ đang chạy PHP <?= PHP_VERSION ?> lúc <?= $time ?>.</p>
</body>
</html>
