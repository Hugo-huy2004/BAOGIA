<?php
declare(strict_types=1);

require __DIR__ . '/includes/bootstrap.php';

if (current_user()) {
    redirect('index.php');
}

$input = ['username' => '', 'display_name' => '', 'email' => '', 'password' => '', 'password_confirm' => ''];
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($input as $key => $_) {
        $input[$key] = trim((string) ($_POST[$key] ?? ''));
    }
    $input['username'] = strtolower($input['username']);
    $errors = validate_registration($input);

    if (!$errors) {
        try {
            $id = create_user($input);
            login_user($id);
            flash('Chào mừng bạn đến với Nhịp!');
            redirect('index.php');
        } catch (PDOException $e) {
            if ($e->getCode() !== '23000') {
                throw $e;                    // lỗi khác: không nuốt
            }
            $errors['username'] = 'Tên người dùng hoặc email đã được dùng.';
        }
    }
}

$title = 'Đăng ký';
$active = 'register';
require __DIR__ . '/includes/header.php';

/** In một ô nhập kèm lỗi của nó. */
function field(string $name, string $label, string $type, array $input, array $errors, string $extra = ''): void
{
    $error = $errors[$name] ?? null;
    $value = $type === 'password' ? '' : $input[$name];
    ?>
    <div class="field">
      <label for="<?= $name ?>"><?= e($label) ?></label>
      <input id="<?= $name ?>" name="<?= $name ?>" type="<?= $type ?>" value="<?= e($value) ?>" required <?= $extra ?>
             <?= $error ? 'aria-invalid="true" aria-describedby="' . $name . '-error"' : '' ?>>
      <?php if ($error): ?>
        <p class="form-error" id="<?= $name ?>-error"><?= e($error) ?></p>
      <?php endif; ?>
    </div>
    <?php
}
?>
  <main class="auth">
    <h1>Tạo tài khoản Nhịp</h1>
    <form method="post" action="register.php" novalidate>
      <?php field('username', 'Tên người dùng', 'text', $input, $errors, 'autocomplete="username" maxlength="30"'); ?>
      <?php field('display_name', 'Tên hiển thị', 'text', $input, $errors, 'autocomplete="name" maxlength="60"'); ?>
      <?php field('email', 'Email', 'email', $input, $errors, 'autocomplete="email"'); ?>
      <?php field('password', 'Mật khẩu (ít nhất 8 ký tự)', 'password', $input, $errors, 'autocomplete="new-password" minlength="8"'); ?>
      <?php field('password_confirm', 'Nhập lại mật khẩu', 'password', $input, $errors, 'autocomplete="new-password"'); ?>
      <button type="submit" class="primary">Đăng ký</button>
    </form>
    <p>Đã có tài khoản? <a href="login.php">Đăng nhập</a></p>
  </main>
<?php require __DIR__ . '/includes/footer.php'; ?>
