  <footer class="site-foot">Nhịp · dự án học tập của khoá Coding</footer>
  <script src="js/app.js" defer></script>
</body>
</html>
