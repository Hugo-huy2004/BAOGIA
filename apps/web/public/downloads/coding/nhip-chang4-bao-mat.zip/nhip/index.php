<?php
declare(strict_types=1);

require __DIR__ . '/includes/bootstrap.php';

$error = null;
$body = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $me = require_login();
    $body = (string) ($_POST['body'] ?? '');
    $error = check_post($body);
    if ($error === null) {
        create_post((int) $me['id'], $body);
        redirect('index.php');
    }
}

$me = current_user();
$tab = ($me && ($_GET['tab'] ?? '') === 'following') ? 'following' : 'latest';
$posts = $tab === 'following' ? following_feed((int) $me['id']) : feed_posts();
$posts = mark_liked($posts, $me);
$title = 'Bảng tin';
$active = 'feed';
require __DIR__ . '/includes/header.php';
?>
  <main class="feed">
    <h1 class="visually-hidden">Bảng tin</h1>

    <?php if (current_user()): ?>
    <form class="composer" method="post" action="index.php">
        <?= csrf_field() ?>
      <label for="body">Có gì mới?</label>
      <textarea id="body" name="body" rows="3" maxlength="<?= MAX_LENGTH ?>" required
                placeholder="Bạn đang nghĩ gì?"><?= e($body) ?></textarea>
      <?php if ($error !== null): ?>
        <p class="form-error" role="alert"><?= e($error) ?></p>
      <?php endif; ?>
      <div class="composer-foot">
        <span><?= MAX_LENGTH ?> ký tự</span>
        <button type="submit">Đăng</button>
      </div>
    </form>
    <?php else: ?>
      <p class="cta"><a href="register.php">Tạo tài khoản</a> hoặc <a href="login.php">đăng nhập</a> để đăng bài.</p>
    <?php endif; ?>

    <?php if ($me): ?>
      <nav class="tabs" aria-label="Chọn bảng tin">
        <a href="index.php" <?= $tab === 'latest' ? 'aria-current="page"' : '' ?>>Mới nhất</a>
        <a href="index.php?tab=following" <?= $tab === 'following' ? 'aria-current="page"' : '' ?>>Đang theo dõi</a>
      </nav>
    <?php endif; ?>

    <section aria-label="Bài đăng" id="posts">
      <?php foreach ($posts as $post): ?>
        <?php require __DIR__ . '/includes/post.php'; ?>
      <?php endforeach; ?>
      <?php if (!$posts): ?>
        <p class="empty">Chưa có bài nào. Hãy là người đầu tiên!</p>
      <?php endif; ?>
    </section>
  </main>
<?php require __DIR__ . '/includes/footer.php'; ?>
