<?php
declare(strict_types=1);

require __DIR__ . '/includes/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    abort(405, 'Phương thức không được phép.');
}
$me = require_login();
$id = id_param($_POST);

if (!delete_post($id, (int) $me['id'])) {
    // Không nói rõ "không tồn tại" hay "không phải của bạn".
    abort(404, 'Không tìm thấy bài để xoá.');
}
log_action('post_delete', (int) $me['id'], 'post #' . $id);
flash('Đã xoá bài.');
redirect('index.php');
