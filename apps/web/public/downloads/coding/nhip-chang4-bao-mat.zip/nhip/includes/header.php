<?php
/** @var string $title  tiêu đề trang
 *  @var string $active trang đang mở */
$me = current_user();
$notice = flash();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($title) ?> · Nhịp</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <header class="topbar">
    <a href="index.php" class="logo">Nhịp</a>
    <nav aria-label="Điều hướng chính">
      <a href="index.php" <?= $active === 'feed' ? 'aria-current="page"' : '' ?>>Bảng tin</a>
      <a href="search.php" <?= $active === 'search' ? 'aria-current="page"' : '' ?>>Tìm</a>
      <?php if ($me): ?>
        <a href="profile.php?u=<?= urlencode($me['username']) ?>" <?= $active === 'profile' ? 'aria-current="page"' : '' ?>>Trang cá nhân</a>
        <form method="post" action="logout.php" class="inline">
        <?= csrf_field() ?>
          <button type="submit" class="link">Đăng xuất</button>
        </form>
      <?php else: ?>
        <a href="login.php" <?= $active === 'login' ? 'aria-current="page"' : '' ?>>Đăng nhập</a>
        <a href="register.php" <?= $active === 'register' ? 'aria-current="page"' : '' ?>>Đăng ký</a>
      <?php endif; ?>
    </nav>
  </header>
  <?php if ($notice !== null): ?>
    <p class="flash" role="status"><?= e($notice) ?></p>
  <?php endif; ?>
