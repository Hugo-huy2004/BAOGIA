<?php
declare(strict_types=1);

/**
 * Khi debug tắt (hosting): mọi lỗi/ngoại lệ không bắt được → trang 500 gọn,
 * không lộ đường dẫn, phiên bản, câu SQL. Lỗi thật được ghi vào nhật ký PHP.
 */
function install_error_handler(bool $debug): void
{
    if ($debug) {
        return;                          // dev: để PHP hiện lỗi chi tiết như cũ
    }
    set_exception_handler(function (Throwable $e): void {
        error_log('[nhip] ' . $e);        // vào log của máy chủ, không ra trình duyệt
        http_response_code(500);
        if (!headers_sent()) {
            header('Content-Type: text/html; charset=UTF-8');
        }
        echo '<!DOCTYPE html><html lang="vi"><head><meta charset="UTF-8">'
            . '<title>Lỗi · Nhịp</title><link rel="stylesheet" href="/nhip/css/style.css"></head>'
            . '<body><main class="feed"><h1>Có lỗi xảy ra</h1>'
            . '<p class="empty">Nhịp gặp sự cố khi xử lý yêu cầu. Hãy thử lại sau.</p>'
            . '<p><a href="/nhip/index.php">← Về bảng tin</a></p></main></body></html>';
        exit;
    });
}
