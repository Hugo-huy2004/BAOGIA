<?php
declare(strict_types=1);

// Mọi trang chỉ cần require tệp này một lần.
require __DIR__ . '/helpers.php';
require __DIR__ . '/db.php';
require __DIR__ . '/posts.php';
require __DIR__ . '/users.php';
require __DIR__ . '/auth.php';
require __DIR__ . '/follows.php';
require __DIR__ . '/uploads.php';
require __DIR__ . '/likes.php';
require __DIR__ . '/security.php';
require __DIR__ . '/csrf.php';
require __DIR__ . '/log.php';
require __DIR__ . '/ratelimit.php';
require __DIR__ . '/errors.php';

$config = require __DIR__ . '/config.php';
ini_set('display_errors', $config['debug'] ? '1' : '0');
error_reporting(E_ALL);
install_error_handler((bool) $config['debug']);

send_security_headers();
start_session();
csrf_check();
