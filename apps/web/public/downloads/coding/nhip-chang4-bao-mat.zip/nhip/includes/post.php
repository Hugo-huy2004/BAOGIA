<?php
/** @var array $post một dòng từ FEED_SQL (đã qua mark_liked) */
$viewer = current_user();
$isOwner = $viewer !== null && (int) $viewer['id'] === (int) $post['user_id'];
$liked = !empty($post['liked']);
?>
<article class="post" data-id="<?= (int) $post['id'] ?>">
  <img class="avatar" src="<?= e($post['avatar'] ?? 'img/avatar.svg') ?>" alt="" width="40" height="40" loading="lazy">
  <div class="post-body">
    <header class="post-head">
      <a class="author" href="profile.php?u=<?= urlencode($post['username']) ?>">
        <?= e($post['display_name']) ?> <span class="handle">@<?= e($post['username']) ?></span>
      </a>
      <a class="when" href="post.php?id=<?= (int) $post['id'] ?>">
        <time datetime="<?= e($post['created_at']) ?>"><?= time_ago($post['created_at']) ?></time>
        <?= $post['updated_at'] ? '· đã sửa' : '' ?>
      </a>
    </header>
    <p class="post-text"><?= e($post['body']) ?></p>
    <footer class="post-actions">
      <form method="post" action="like.php" class="inline like-form">
        <?= csrf_field() ?>
        <input type="hidden" name="post_id" value="<?= (int) $post['id'] ?>">
        <button type="submit" class="like" aria-pressed="<?= $liked ? 'true' : 'false' ?>"
                aria-label="<?= $liked ? 'Bỏ thích' : 'Thích' ?>">♥ <span><?= (int) $post['likes'] ?></span></button>
      </form>
      <a class="action" href="post.php?id=<?= (int) $post['id'] ?>">Trả lời <?= (int) $post['replies'] ?: '' ?></a>
      <?php if ($isOwner): ?>
        <a class="action" href="edit.php?id=<?= (int) $post['id'] ?>">Sửa</a>
        <form method="post" action="delete.php" class="inline" data-confirm="Xoá bài này? Không hoàn tác được.">
        <?= csrf_field() ?>
          <input type="hidden" name="id" value="<?= (int) $post['id'] ?>">
          <button type="submit" class="action danger">Xoá</button>
        </form>
      <?php endif; ?>
    </footer>
  </div>
</article>
