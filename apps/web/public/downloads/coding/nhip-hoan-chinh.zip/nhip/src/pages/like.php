<?php
declare(strict_types=1);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    abort(405, 'Phương thức không được phép.');
}
$wantsJson = str_contains($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json');
$me = current_user();
$post = find_post(id_param($_POST, 'post_id'));

if ($me === null || $post === null) {
    if ($wantsJson) {
        http_response_code($me === null ? 401 : 404);
        header('Content-Type: application/json');
        echo json_encode(['error' => $me === null ? 'Hãy đăng nhập để thả tim.' : 'Không tìm thấy bài.']);
        exit;
    }
    $me === null ? require_login() : abort(404, 'Không tìm thấy bài.');
}

$result = toggle_like((int) $me['id'], (int) $post['id']);
if ($result['liked']) {
    notify((int) $post['user_id'], (int) $me['id'], 'like', (int) $post['id']);
}

if ($wantsJson) {
    // fetch() trong js/app.js: trả JSON, trang không tải lại.
    header('Content-Type: application/json');
    echo json_encode($result);
    exit;
}
// Không có JavaScript: biểu mẫu thường, quay về trang của bài.
redirect(url('post', ['id' => (int) $post['id']]));
