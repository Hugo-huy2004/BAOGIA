<?php
declare(strict_types=1);

/** Mở phiên với cookie an toàn. Gọi một lần ở bootstrap, trước khi in bất cứ gì. */
function start_session(): void
{
    session_set_cookie_params([
        'lifetime' => 0,          // cookie mất khi đóng trình duyệt
        'path'     => '/',
        'httponly' => true,       // JavaScript không đọc được cookie phiên
        'samesite' => 'Lax',      // không gửi kèm yêu cầu POST từ trang khác
    ]);
    session_name('nhip_session');
    session_start();
}

/** Người đang đăng nhập (đọc lại từ cơ sở dữ liệu), hoặc null. */
function current_user(): ?array
{
    static $user = false;
    if ($user === false) {
        $id = $_SESSION['user_id'] ?? null;
        $user = is_int($id) ? find_user_by_id($id) : null;
    }
    return $user;
}

/** Trang chỉ dành cho người đã đăng nhập: chưa đăng nhập thì chuyển tới login.php. */
function require_login(): array
{
    $user = current_user();
    if ($user === null) {
        flash('Hãy đăng nhập để tiếp tục.');
        redirect('login.php');
    }
    return $user;
}

function login_user(int $userId): void
{
    session_regenerate_id(true);   // đổi mã phiên: chặn tấn công cố định phiên
    $_SESSION['user_id'] = $userId;
}

function logout_user(): void
{
    $_SESSION = [];
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 3600, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    session_destroy();
}
