<?php
declare(strict_types=1);

/** Người được xem thống kê — ở Nhịp là tài khoản đầu tiên (chủ sản phẩm). */
const STATS_OWNER_ID = 1;

function overview_stats(): array
{
    return db()->query('SELECT
        (SELECT COUNT(*) FROM users)                            AS users,
        (SELECT COUNT(*) FROM posts WHERE parent_id IS NULL)    AS posts,
        (SELECT COUNT(*) FROM posts WHERE parent_id IS NOT NULL) AS replies,
        (SELECT COUNT(*) FROM likes)                            AS likes,
        (SELECT COUNT(*) FROM follows)                          AS follows')->fetch();
}

/** Bài mới mỗi ngày trong N ngày gần nhất (điền cả ngày không có bài = 0). */
function posts_per_day(int $days = 7): array
{
    $stmt = db()->prepare('SELECT DATE(created_at) AS d, COUNT(*) AS n
        FROM posts WHERE created_at > (NOW() - INTERVAL :days DAY)
        GROUP BY DATE(created_at)');
    $stmt->bindValue(':days', $days, PDO::PARAM_INT);
    $stmt->execute();
    $byDay = [];
    foreach ($stmt->fetchAll() as $row) {
        $byDay[$row['d']] = (int) $row['n'];
    }
    $series = [];
    for ($i = $days - 1; $i >= 0; $i--) {
        $d = date('Y-m-d', strtotime("-$i day"));
        $series[] = ['day' => $d, 'n' => $byDay[$d] ?? 0];
    }
    return $series;
}

function top_posters(int $limit = 5): array
{
    $stmt = db()->prepare('SELECT u.username, u.display_name, COUNT(*) AS n
        FROM posts AS p JOIN users AS u ON u.id = p.user_id
        WHERE p.parent_id IS NULL GROUP BY u.id ORDER BY n DESC LIMIT :limit');
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

function failed_logins_7d(): int
{
    return (int) db()->query("SELECT COUNT(*) FROM activity_log
        WHERE action = 'login_failed' AND created_at > (NOW() - INTERVAL 7 DAY)")->fetchColumn();
}
