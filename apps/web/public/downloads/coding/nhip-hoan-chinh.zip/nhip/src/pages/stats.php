<?php
declare(strict_types=1);

$me = require_login();
if ((int) $me['id'] !== STATS_OWNER_ID) {
    abort(403, 'Chỉ chủ sản phẩm xem được trang này.');
}

$overview = overview_stats();
$daily = posts_per_day(7);
$peak = max(array_map(fn ($d) => $d['n'], $daily)) ?: 1;   // để chia tỉ lệ cột
$posters = top_posters();
$failed = failed_logins_7d();
$engagement = $overview['posts'] > 0 ? round($overview['likes'] / $overview['posts'], 2) : 0;

$title = 'Thống kê';
$active = '';
require view('header');
?>
  <main class="feed stats">
    <h1>Thống kê Nhịp</h1>

    <div class="stat-cards">
      <?php foreach ([
        ['Người dùng', $overview['users']],
        ['Bài gốc', $overview['posts']],
        ['Trả lời', $overview['replies']],
        ['Lượt tim', $overview['likes']],
        ['Theo dõi', $overview['follows']],
        ['Tim / bài', $engagement],
      ] as [$label, $value]): ?>
        <div class="stat-card">
          <b><?= e((string) $value) ?></b>
          <span><?= e($label) ?></span>
        </div>
      <?php endforeach; ?>
    </div>

    <h2>Bài mới 7 ngày qua</h2>
    <div class="chart" role="img" aria-label="Biểu đồ bài mới mỗi ngày trong 7 ngày">
      <?php foreach ($daily as $d): ?>
        <div class="bar-col">
          <?php $pct = (int) (round($d['n'] / $peak * 20) * 5); ?>
          <div class="bar bar-h-<?= $pct ?>">
            <span class="bar-value"><?= (int) $d['n'] ?></span>
          </div>
          <span class="bar-label"><?= e(date('d/m', strtotime($d['day']))) ?></span>
        </div>
      <?php endforeach; ?>
    </div>

    <h2>Người đăng nhiều nhất</h2>
    <ol class="rank">
      <?php foreach ($posters as $p): ?>
        <li><a href="<?= url('profile', ['username' => $p['username']]) ?>"><?= e($p['display_name']) ?></a> — <?= (int) $p['n'] ?> bài</li>
      <?php endforeach; ?>
    </ol>

    <h2>An ninh</h2>
    <p>Đăng nhập sai 7 ngày qua: <strong><?= $failed ?></strong> lần<?= $failed > 20 ? ' — đáng chú ý' : '' ?>.</p>
  </main>
<?php require view('footer'); ?>
