<?php
declare(strict_types=1);

const LOGIN_MAX_ATTEMPTS = 5;        // tối đa 5 lần sai
const LOGIN_WINDOW_MIN = 15;         // trong 15 phút, tính theo IP

/** Số lần thử đăng nhập của IP này trong cửa sổ thời gian. */
function login_attempt_count(): int
{
    $stmt = db()->prepare('SELECT COUNT(*) FROM login_attempts
        WHERE ip = ? AND created_at > (NOW() - INTERVAL ? MINUTE)');
    $stmt->execute([client_ip(), LOGIN_WINDOW_MIN]);
    return (int) $stmt->fetchColumn();
}

function record_login_attempt(string $login): void
{
    db()->prepare('INSERT INTO login_attempts (ip, login) VALUES (?, ?)')
        ->execute([client_ip(), mb_substr($login, 0, 255)]);
}

/** Đăng nhập đúng rồi thì xoá lịch sử thử của IP này. */
function clear_login_attempts(): void
{
    db()->prepare('DELETE FROM login_attempts WHERE ip = ?')->execute([client_ip()]);
}
