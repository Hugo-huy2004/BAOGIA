<?php
declare(strict_types=1);

$error = null;
$body = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $me = require_login();
    $body = (string) ($_POST['body'] ?? '');
    $error = check_post($body);
    if ($error === null) {
        publish_post((int) $me['id'], $body);
        redirect(url('feed'));
    }
}

$me = current_user();
$tab = ($me && ($_GET['tab'] ?? '') === 'following') ? 'following' : 'latest';

const FEED_PER_PAGE = 20;
// Con trỏ keyset "created_at|id" của bài cuối trang trước (nếu có).
$before = null;
if (preg_match('/^(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)\|(\d+)$/', (string) ($_GET['before'] ?? ''), $m)) {
    $before = ['created_at' => $m[1], 'id' => (int) $m[2]];
}

if ($tab === 'following') {
    $posts = following_feed((int) $me['id']);
    $hasMore = false;
} else {
    $posts = feed_posts(FEED_PER_PAGE, $before);
    $hasMore = count($posts) > FEED_PER_PAGE;         // lấy dư 1 để biết còn trang sau
    $posts = array_slice($posts, 0, FEED_PER_PAGE);
}
$posts = mark_liked($posts, $me);
$title = 'Bảng tin';
$active = 'feed';
require view('header');
?>
  <main class="feed">
    <h1 class="visually-hidden">Bảng tin</h1>

    <?php if (current_user()): ?>
    <form class="composer" method="post" action="<?= url('posts.create') ?>">
        <?= csrf_field() ?>
      <label for="body">Có gì mới?</label>
      <textarea id="body" name="body" rows="3" maxlength="<?= MAX_LENGTH ?>" required
                placeholder="Bạn đang nghĩ gì?"><?= e($body) ?></textarea>
      <?php if ($error !== null): ?>
        <p class="form-error" role="alert"><?= e($error) ?></p>
      <?php endif; ?>
      <div class="composer-foot">
        <span><?= MAX_LENGTH ?> ký tự</span>
        <button type="submit">Đăng</button>
      </div>
    </form>
    <?php else: ?>
      <p class="cta"><a href="<?= url('register') ?>">Tạo tài khoản</a> hoặc <a href="<?= url('login') ?>">đăng nhập</a> để đăng bài.</p>
    <?php endif; ?>

    <?php if ($me): ?>
      <nav class="tabs" aria-label="Chọn bảng tin">
        <a href="<?= url('feed') ?>" <?= $tab === 'latest' ? 'aria-current="page"' : '' ?>>Mới nhất</a>
        <a href="<?= url('feed', ['tab' => 'following']) ?>" <?= $tab === 'following' ? 'aria-current="page"' : '' ?>>Đang theo dõi</a>
      </nav>
    <?php endif; ?>

    <section aria-label="Bài đăng" id="posts">
      <?php foreach ($posts as $post): ?>
        <?php require view('post'); ?>
      <?php endforeach; ?>
      <?php if (!$posts): ?>
        <p class="empty">Chưa có bài nào. Hãy là người đầu tiên!</p>
      <?php endif; ?>
    </section>

    <?php if (!empty($hasMore)): $last = end($posts); ?>
      <p class="more">
        <a href="<?= url('feed', ['before' => $last['created_at'] . '|' . $last['id']]) ?>">Xem thêm</a>
      </p>
    <?php endif; ?>
  </main>
<?php require view('footer'); ?>
