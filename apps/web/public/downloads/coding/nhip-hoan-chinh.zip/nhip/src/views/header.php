<?php
/** @var string $title  tiêu đề trang
 *  @var string $active trang đang mở */
$me = current_user();
$notice = flash();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($title) ?> · Nhịp</title>
  <meta name="description" content="Nhịp — mạng xã hội chia sẻ bài viết ngắn. Dự án học tập của khoá Coding, Hugo Studio.">
  <link rel="stylesheet" href="<?= asset('css/style.css') ?>">
</head>
<body data-base="<?= e(base_path()) ?>">
  <header class="topbar">
    <a href="<?= url('feed') ?>" class="logo">Nhịp</a>
    <nav aria-label="Điều hướng chính">
      <a href="<?= url('feed') ?>" <?= $active === 'feed' ? 'aria-current="page"' : '' ?>>Bảng tin</a>
      <a href="<?= url('search') ?>" <?= $active === 'search' ? 'aria-current="page"' : '' ?>>Tìm</a>
      <?php if ($me): ?>
        <a href="<?= url('notifications') ?>" <?= $active === 'notifications' ? 'aria-current="page"' : '' ?>>
          Thông báo<?php $u = unread_count((int) $me['id']); if ($u): ?> <span class="badge"><?= $u ?></span><?php endif; ?>
        </a>
        <a href="<?= url('profile', ['username' => $me['username']]) ?>" <?= $active === 'profile' ? 'aria-current="page"' : '' ?>>Trang cá nhân</a>
        <form method="post" action="<?= url('logout') ?>" class="inline">
        <?= csrf_field() ?>
          <button type="submit" class="link">Đăng xuất</button>
        </form>
      <?php else: ?>
        <a href="<?= url('login') ?>" <?= $active === 'login' ? 'aria-current="page"' : '' ?>>Đăng nhập</a>
        <a href="<?= url('register') ?>" <?= $active === 'register' ? 'aria-current="page"' : '' ?>>Đăng ký</a>
      <?php endif; ?>
    </nav>
  </header>
  <?php if ($notice !== null): ?>
    <p class="flash" role="status"><?= e($notice) ?></p>
  <?php endif; ?>
