<?php
declare(strict_types=1);

/**
 * Bật/tắt tim của $userId cho bài $postId. Trả trạng thái mới và tổng số tim.
 * Thử INSERT trước; nếu đã có (0 dòng được thêm) thì đó là lần bấm để bỏ tim.
 */
function toggle_like(int $userId, int $postId): array
{
    $insert = db()->prepare('INSERT IGNORE INTO likes (user_id, post_id) VALUES (?, ?)');
    $insert->execute([$userId, $postId]);
    $liked = $insert->rowCount() === 1;
    if (!$liked) {
        db()->prepare('DELETE FROM likes WHERE user_id = ? AND post_id = ?')->execute([$userId, $postId]);
    }
    $count = db()->prepare('SELECT COUNT(*) FROM likes WHERE post_id = ?');
    $count->execute([$postId]);
    return ['liked' => $liked, 'likes' => (int) $count->fetchColumn()];
}

/**
 * Đánh dấu bài nào người xem đã thả tim — MỘT truy vấn cho cả danh sách,
 * không phải một truy vấn mỗi bài.
 */
function mark_liked(array $posts, ?array $viewer): array
{
    if ($viewer === null || !$posts) {
        return $posts;
    }
    $ids = array_map(fn (array $p): int => (int) $p['id'], $posts);
    $marks = implode(',', array_fill(0, count($ids), '?'));            // ?,?,?
    $stmt = db()->prepare("SELECT post_id FROM likes WHERE user_id = ? AND post_id IN ($marks)");
    $stmt->execute([(int) $viewer['id'], ...$ids]);
    $liked = array_flip($stmt->fetchAll(PDO::FETCH_COLUMN));
    foreach ($posts as &$post) {
        $post['liked'] = isset($liked[$post['id']]);
    }
    return $posts;
}
