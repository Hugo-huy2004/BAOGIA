<?php
declare(strict_types=1);

$tag = (string) route_param('tag');
$posts = mark_liked(posts_by_tag($tag), current_user());

$title = '#' . $tag;
$active = '';
require view('header');
?>
  <main class="feed">
    <h1>#<?= e($tag) ?></h1>
    <?php if (!$posts): ?>
      <p class="empty">Chưa có bài nào mang thẻ này.</p>
    <?php endif; ?>
    <section aria-label="Bài mang thẻ <?= e($tag) ?>">
      <?php foreach ($posts as $post): ?>
        <?php require view('post'); ?>
      <?php endforeach; ?>
    </section>
  </main>
<?php require view('footer'); ?>
