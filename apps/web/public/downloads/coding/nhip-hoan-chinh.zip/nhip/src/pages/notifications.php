<?php
declare(strict_types=1);

$me = require_login();
$items = notifications_for((int) $me['id']);
mark_notifications_read((int) $me['id']);        // mở trang = đã xem

$verb = [
    'reply'   => 'đã trả lời bài của bạn',
    'like'    => 'đã thích bài của bạn',
    'follow'  => 'đã theo dõi bạn',
    'mention' => 'đã nhắc tới bạn',
];

$title = 'Thông báo';
$active = 'notifications';
require view('header');
?>
  <main class="feed">
    <h1>Thông báo</h1>
    <?php if (!$items): ?>
      <p class="empty">Chưa có thông báo nào.</p>
    <?php endif; ?>
    <ul class="notif-list">
      <?php foreach ($items as $n): ?>
        <li class="notif <?= $n['is_read'] ? '' : 'is-unread' ?>">
          <img class="avatar" src="<?= e(avatar_url(['avatar' => $n['actor_avatar']])) ?>" alt="" width="36" height="36" loading="lazy">
          <span>
            <a class="author" href="<?= url('profile', ['username' => $n['actor_name']]) ?>"><?= e($n['actor_display']) ?></a>
            <?= e($verb[$n['type']] ?? 'có hoạt động mới') ?>
            <?php if ($n['post_id']): ?>
              · <a href="<?= url('post', ['id' => (int) $n['post_id']]) ?>">xem bài</a>
            <?php endif; ?>
            <time datetime="<?= e($n['created_at']) ?>"><?= time_ago($n['created_at']) ?></time>
          </span>
        </li>
      <?php endforeach; ?>
    </ul>
  </main>
<?php require view('footer'); ?>
