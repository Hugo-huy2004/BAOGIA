<?php
declare(strict_types=1);

const USER_COLUMNS = 'u.id, u.username, u.display_name, u.bio, u.avatar, u.created_at';

/** Một người dùng theo tên, kèm số người theo dõi / đang theo dõi. null nếu không có. */
function find_user_by_username(string $username): ?array
{
    $stmt = db()->prepare('
        SELECT ' . USER_COLUMNS . ',
               (SELECT COUNT(*) FROM follows WHERE followee_id = u.id) AS followers,
               (SELECT COUNT(*) FROM follows WHERE follower_id = u.id) AS following
        FROM users AS u
        WHERE u.username = ?');
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    return $user === false ? null : $user;
}

function find_user_by_id(int $id): ?array
{
    $stmt = db()->prepare('SELECT ' . USER_COLUMNS . ' FROM users AS u WHERE u.id = ?');
    $stmt->execute([$id]);
    $user = $stmt->fetch();
    return $user === false ? null : $user;
}

/** Kiểm tra tên đăng nhập (tên người dùng HOẶC email) + mật khẩu. Trả id hoặc null. */
function verify_login(string $login, string $password): ?int
{
    $stmt = db()->prepare('SELECT id, password_hash FROM users WHERE username = ? OR email = ?');
    $stmt->execute([$login, $login]);
    $row = $stmt->fetch();

    // Không có người dùng vẫn băm một lần: thời gian trả lời như nhau nên kẻ
    // tấn công không đo được tên nào có thật.
    $hash = $row['password_hash'] ?? password_hash('nhip', PASSWORD_DEFAULT);
    $ok = password_verify($password, $hash);
    if (!$row || !$ok) {
        return null;
    }
    if (password_needs_rehash($row['password_hash'], PASSWORD_DEFAULT)) {
        db()->prepare('UPDATE users SET password_hash = ? WHERE id = ?')
            ->execute([password_hash($password, PASSWORD_DEFAULT), $row['id']]);
    }
    return (int) $row['id'];
}

/** Kiểm tra dữ liệu đăng ký. Trả mảng lỗi theo tên trường (rỗng = hợp lệ). */
function validate_registration(array $input): array
{
    $errors = [];
    if (!preg_match('/^[a-z0-9._]{3,30}$/', $input['username'])) {
        $errors['username'] = 'Tên người dùng 3–30 ký tự: chữ thường không dấu, số, dấu chấm, gạch dưới.';
    }
    if (mb_strlen($input['display_name']) < 1 || mb_strlen($input['display_name']) > 60) {
        $errors['display_name'] = 'Tên hiển thị 1–60 ký tự.';
    }
    if (filter_var($input['email'], FILTER_VALIDATE_EMAIL) === false) {
        $errors['email'] = 'Email không hợp lệ.';
    }
    if (strlen($input['password']) < 8 || strlen($input['password']) > 72) {
        $errors['password'] = 'Mật khẩu 8–72 ký tự.';
    } elseif ($input['password'] !== $input['password_confirm']) {
        $errors['password_confirm'] = 'Hai lần nhập mật khẩu không khớp.';
    }
    return $errors;
}

/** Tạo tài khoản. Ném PDOException mã 23000 nếu trùng tên người dùng hoặc email. */
function create_user(array $input): int
{
    $stmt = db()->prepare('
        INSERT INTO users (username, display_name, email, password_hash)
        VALUES (:username, :display_name, :email, :password_hash)');
    $stmt->execute([
        'username'      => $input['username'],
        'display_name'  => $input['display_name'],
        'email'         => $input['email'],
        'password_hash' => password_hash($input['password'], PASSWORD_DEFAULT),
    ]);
    return (int) db()->lastInsertId();
}

function update_profile(int $id, string $displayName, string $bio, ?string $avatar): void
{
    db()->prepare('UPDATE users SET display_name = ?, bio = ?, avatar = ? WHERE id = ?')
        ->execute([$displayName, $bio, $avatar, $id]);
}
