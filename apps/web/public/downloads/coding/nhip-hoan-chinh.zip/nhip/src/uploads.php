<?php
declare(strict_types=1);

const AVATAR_DIR = __DIR__ . '/../uploads/avatars/';
const AVATAR_MAX_BYTES = 2 * 1024 * 1024;              // 2 MB
const AVATAR_TYPES = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];

/**
 * Lưu ảnh đại diện tải lên. Trả đường dẫn tương đối để lưu vào users.avatar.
 * Ném RuntimeException với câu báo lỗi cho người dùng nếu tệp không hợp lệ.
 */
function save_avatar(array $file): string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Tải ảnh lên không thành công.');
    }
    if ($file['size'] > AVATAR_MAX_BYTES) {
        throw new RuntimeException('Ảnh tối đa 2 MB.');
    }
    // Đọc kiểu tệp từ NỘI DUNG, không tin tên tệp hay kiểu trình duyệt gửi.
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    if (!isset(AVATAR_TYPES[$mime]) || getimagesize($file['tmp_name']) === false) {
        throw new RuntimeException('Chỉ nhận ảnh JPG, PNG hoặc WebP.');
    }
    // Vẽ lại ảnh bằng GD: đọc pixel rồi ghi ra tệp mới, bỏ mọi dữ liệu thừa
    // (mã giấu trong khối metadata) — ảnh "đa hợp" ảnh+PHP không sống sót bước này.
    $image = match ($mime) {
        'image/jpeg' => imagecreatefromjpeg($file['tmp_name']),
        'image/png'  => imagecreatefrompng($file['tmp_name']),
        'image/webp' => imagecreatefromwebp($file['tmp_name']),
    };
    if ($image === false) {
        throw new RuntimeException('Không đọc được ảnh.');
    }
    // Tên mới hoàn toàn ngẫu nhiên: không đoán được, không đè tệp khác, không mang đuôi lạ.
    $name = bin2hex(random_bytes(16)) . '.' . AVATAR_TYPES[$mime];
    $path = AVATAR_DIR . $name;
    $saved = match ($mime) {
        'image/jpeg' => imagejpeg($image, $path, 85),
        'image/png'  => imagepng($image, $path),
        'image/webp' => imagewebp($image, $path, 85),
    };
    imagedestroy($image);
    if (!$saved) {
        throw new RuntimeException('Không lưu được ảnh.');
    }
    return 'uploads/avatars/' . $name;
}

/** Xoá ảnh cũ khi người dùng đổi ảnh — chỉ xoá tệp nằm đúng trong thư mục ảnh đại diện. */
function delete_avatar(?string $path): void
{
    if ($path !== null && preg_match('#^uploads/avatars/[a-f0-9]{32}\.(jpg|png|webp)$#', $path)) {
        @unlink(__DIR__ . '/../' . $path);
    }
}
