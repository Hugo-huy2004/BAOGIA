<?php
declare(strict_types=1);

// Mọi câu SQL về bài đăng nằm ở đây. Trang PHP chỉ gọi hàm, không viết SQL.

const FEED_SQL = '
    SELECT p.id, p.user_id, p.parent_id, p.body, p.created_at, p.updated_at, u.username, u.display_name, u.avatar,
           COUNT(l.user_id) AS likes,
           (SELECT COUNT(*) FROM posts AS r WHERE r.parent_id = p.id) AS replies
    FROM posts AS p
    JOIN users AS u ON u.id = p.user_id
    LEFT JOIN likes AS l ON l.post_id = p.id';

/**
 * 20 bài gốc mới nhất cho bảng tin. $before là con trỏ keyset (bài cuối trang
 * trước): chỉ lấy bài CŨ hơn nó. Lấy $limit + 1 để biết còn trang sau không.
 */
function feed_posts(int $limit = 20, ?array $before = null): array
{
    $cursor = $before
        ? 'AND (p.created_at, p.id) < (:before_at, :before_id)'
        : '';
    $stmt = db()->prepare(FEED_SQL . "
        WHERE p.parent_id IS NULL $cursor
        GROUP BY p.id
        ORDER BY p.created_at DESC, p.id DESC
        LIMIT :limit");
    if ($before) {
        $stmt->bindValue(':before_at', $before['created_at']);
        $stmt->bindValue(':before_id', (int) $before['id'], PDO::PARAM_INT);
    }
    $stmt->bindValue(':limit', $limit + 1, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

/** Bài gốc của một người dùng, cho trang cá nhân. */
function posts_by_user(int $userId): array
{
    $stmt = db()->prepare(FEED_SQL . '
        WHERE p.parent_id IS NULL AND p.user_id = :user_id
        GROUP BY p.id
        ORDER BY p.created_at DESC, p.id DESC');
    $stmt->execute(['user_id' => $userId]);
    return $stmt->fetchAll();
}

/** Thêm bài, trả id của bài mới. */
function create_post(int $userId, string $body): int
{
    $stmt = db()->prepare('INSERT INTO posts (user_id, body) VALUES (:user_id, :body)');
    $stmt->execute(['user_id' => $userId, 'body' => trim($body)]);
    return (int) db()->lastInsertId();
}

/** Một bài theo id (kể cả câu trả lời), hoặc null. */
function find_post(int $id): ?array
{
    $stmt = db()->prepare(FEED_SQL . ' WHERE p.id = ? GROUP BY p.id');
    $stmt->execute([$id]);
    $post = $stmt->fetch();
    return $post === false ? null : $post;
}

/**
 * Sửa bài. Điều kiện user_id nằm NGAY TRONG câu UPDATE: không phải chủ bài thì
 * không dòng nào khớp. Trả true nếu đã sửa.
 */
function update_post(int $id, int $userId, string $body): bool
{
    $stmt = db()->prepare('
        UPDATE posts SET body = :body, updated_at = NOW()
        WHERE id = :id AND user_id = :user_id');
    $stmt->execute(['body' => trim($body), 'id' => $id, 'user_id' => $userId]);
    return $stmt->rowCount() === 1;
}

/** Xoá bài của chính mình. Câu trả lời và lượt tim tự xoá theo (ON DELETE CASCADE). */
function delete_post(int $id, int $userId): bool
{
    $stmt = db()->prepare('DELETE FROM posts WHERE id = ? AND user_id = ?');
    $stmt->execute([$id, $userId]);
    return $stmt->rowCount() === 1;
}

/** Thêm câu trả lời cho bài $parentId. */
function create_reply(int $userId, int $parentId, string $body): int
{
    $stmt = db()->prepare('INSERT INTO posts (user_id, parent_id, body) VALUES (?, ?, ?)');
    $stmt->execute([$userId, $parentId, trim($body)]);
    return (int) db()->lastInsertId();
}

/**
 * Mọi câu trả lời nằm dưới bài $rootId, ở mọi tầng, dựng thành cây.
 * WITH RECURSIVE đi xuống từng tầng cho tới khi hết con.
 */
function reply_tree(int $rootId): array
{
    $stmt = db()->prepare('
        WITH RECURSIVE thread AS (
            SELECT id, 1 AS depth FROM posts WHERE parent_id = :root
            UNION ALL
            SELECT c.id, t.depth + 1 FROM posts AS c JOIN thread AS t ON c.parent_id = t.id
        )
        ' . FEED_SQL . '
        JOIN thread AS t ON t.id = p.id
        GROUP BY p.id
        ORDER BY p.created_at ASC, p.id ASC');
    $stmt->execute(['root' => $rootId]);

    // Gom danh sách phẳng thành cây: mỗi bài nhận mảng children.
    $byParent = [];
    foreach ($stmt->fetchAll() as $row) {
        $byParent[(int) $row['parent_id']][] = $row;
    }
    $build = function (int $parentId) use (&$build, $byParent): array {
        $nodes = $byParent[$parentId] ?? [];
        foreach ($nodes as &$node) {
            $node['children'] = $build((int) $node['id']);
        }
        return $nodes;
    };
    return $build($rootId);
}

/** Tìm bài theo nội dung. % và _ của người dùng được thoát để LIKE hiểu là chữ thường. */
function search_posts(string $query, int $limit = 20): array
{
    $pattern = '%' . addcslashes($query, '%_\\') . '%';
    $stmt = db()->prepare(FEED_SQL . '
        WHERE p.body LIKE :pattern
        GROUP BY p.id
        ORDER BY p.created_at DESC
        LIMIT :limit');
    $stmt->bindValue(':pattern', $pattern);
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

/**
 * Đăng một bài (hoặc trả lời) kèm hashtag và thông báo — TẤT CẢ trong một giao
 * dịch: hoặc tất cả thành công, hoặc không gì cả (step 11). Trả id bài mới.
 */
function publish_post(int $userId, string $body, ?int $parentId = null): int
{
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $postId = $parentId === null
            ? create_post($userId, $body)
            : create_reply($userId, $parentId, $body);

        attach_tags($postId, extract_tags($body));
        notify_mentions($body, $userId, $postId);

        if ($parentId !== null) {
            $parent = find_post($parentId);
            if ($parent !== null) {
                notify((int) $parent['user_id'], $userId, 'reply', $parentId);
            }
        }
        $pdo->commit();
        return $postId;
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
}

/**
 * In nội dung bài an toàn, biến #hashtag và @tên thành liên kết.
 * Thoát HTML TRƯỚC (chống XSS), rồi mới thêm liên kết trên chuỗi đã thoát.
 */
function render_body(string $body): string
{
    $safe = e($body);
    $safe = preg_replace_callback('/#([\p{L}\p{N}_]{1,50})/u', function ($m) {
        return '<a class="tag" href="' . e(url('tag', ['tag' => mb_strtolower($m[1])])) . '">#' . $m[1] . '</a>';
    }, $safe);
    $safe = preg_replace_callback('/@([a-z0-9._]{3,30})/', function ($m) {
        return '<a class="mention" href="' . e(url('profile', ['username' => $m[1]])) . '">@' . $m[1] . '</a>';
    }, $safe);
    return nl2br($safe, false);
}
