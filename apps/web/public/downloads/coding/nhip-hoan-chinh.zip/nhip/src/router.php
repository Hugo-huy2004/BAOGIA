<?php
declare(strict_types=1);

/**
 * Bảng tuyến: [phương thức, mẫu đường dẫn] => [tên handler trong src/pages, tên tuyến].
 * {id}, {username} là tham số; handler đọc qua route_param().
 */
const ROUTES = [
    ['GET',  '/',              'feed',     'feed'],
    ['POST', '/posts',         'feed',     'posts.create'],
    ['GET',  '/login',         'login',    'login'],
    ['POST', '/login',         'login',    'login.post'],
    ['POST', '/logout',        'logout',   'logout'],
    ['GET',  '/register',      'register', 'register'],
    ['POST', '/register',      'register', 'register.post'],
    ['GET',  '/search',        'search',   'search'],
    ['GET',  '/settings',      'settings', 'settings'],
    ['POST', '/settings',      'settings', 'settings.post'],
    ['POST', '/like',          'like',     'like'],
    ['POST', '/follow',        'follow',   'follow'],
    ['POST', '/delete',        'delete',   'delete'],
    ['GET',  '/post/{id}',     'post',     'post'],
    ['POST', '/post/{id}',     'post',     'post.reply'],
    ['GET',  '/edit/{id}',     'edit',     'edit'],
    ['POST', '/edit/{id}',     'edit',     'edit.post'],
    ['GET',  '/notifications', 'notifications', 'notifications'],
    ['GET',  '/stats',         'stats',        'stats'],
    ['GET',  '/tag/{tag}',     'tag',          'tag'],
    ['GET',  '/u/{username}',  'profile',  'profile'],
];

$GLOBALS['route_params'] = [];

/** Thư mục gốc công khai, suy từ script đang chạy: ví dụ "/nhip/public". */
function base_path(): string
{
    return rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
}

/** Dựng URL cho một tuyến đã đặt tên: url('post', ['id' => 5]) => /nhip/public/post/5 */
function url(string $name, array $params = []): string
{
    foreach (ROUTES as [$method, $pattern, $page, $routeName]) {
        if ($routeName !== $name) {
            continue;
        }
        $path = preg_replace_callback('/\{(\w+)\}/', function ($m) use (&$params) {
            $key = $m[1];
            $value = rawurlencode((string) ($params[$key] ?? ''));
            unset($params[$key]);
            return $value;
        }, $pattern);
        $query = $params ? '?' . http_build_query($params) : '';
        return base_path() . $path . $query;
    }
    return base_path() . '/';
}

/** Đường dẫn tới tài nguyên tĩnh trong public/. */
function asset(string $path): string
{
    return base_path() . '/' . ltrim($path, '/');
}

function route_param(string $key, $default = null)
{
    return $GLOBALS['route_params'][$key] ?? $default;
}

/** Khớp yêu cầu với bảng tuyến rồi chạy handler. */
function dispatch(): void
{
    $method = $_SERVER['REQUEST_METHOD'];
    $path = rawurldecode(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?? '/');
    $path = '/' . ltrim(substr($path, strlen(base_path())), '/');
    $path = rtrim($path, '/') ?: '/';

    foreach (ROUTES as [$routeMethod, $pattern, $page, $name]) {
        $regex = '#^' . preg_replace('/\{(\w+)\}/', '(?<$1>[^/]+)', $pattern) . '$#';
        if ($routeMethod === $method && preg_match($regex, $path, $m)) {
            $GLOBALS['route_params'] = array_filter($m, 'is_string', ARRAY_FILTER_USE_KEY);
            require __DIR__ . '/pages/' . $page . '.php';
            return;
        }
    }
    abort(404, 'Trang không tồn tại.');
}
