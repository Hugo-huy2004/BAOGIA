<?php
declare(strict_types=1);

/** Trích hashtag từ nội dung: "#php, #CSS." → ['php', 'css'] (chữ thường, không trùng). */
function extract_tags(string $body): array
{
    preg_match_all('/#([\p{L}\p{N}_]{1,50})/u', $body, $m);
    return array_values(array_unique(array_map('mb_strtolower', $m[1])));
}

/** Trích tên người được nhắc: "@lan.code" → ['lan.code']. */
function extract_mentions(string $body): array
{
    preg_match_all('/@([a-z0-9._]{3,30})/', $body, $m);
    return array_values(array_unique($m[1]));
}

/** Gắn các hashtag cho một bài (tạo tag nếu chưa có). */
function attach_tags(int $postId, array $tags): void
{
    foreach ($tags as $name) {
        db()->prepare('INSERT IGNORE INTO tags (name) VALUES (?)')->execute([$name]);
        $id = db()->prepare('SELECT id FROM tags WHERE name = ?');
        $id->execute([$name]);
        db()->prepare('INSERT IGNORE INTO post_tags (post_id, tag_id) VALUES (?, ?)')
            ->execute([$postId, (int) $id->fetchColumn()]);
    }
}

/** Bài gốc mang một hashtag, mới nhất trước. */
function posts_by_tag(string $tag, int $limit = 20): array
{
    $stmt = db()->prepare(FEED_SQL . '
        JOIN post_tags AS pt ON pt.post_id = p.id
        JOIN tags AS t ON t.id = pt.tag_id
        WHERE t.name = :tag
        GROUP BY p.id
        ORDER BY p.created_at DESC, p.id DESC
        LIMIT :limit');
    $stmt->bindValue(':tag', mb_strtolower($tag));
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}
