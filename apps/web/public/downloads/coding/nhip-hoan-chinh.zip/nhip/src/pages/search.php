<?php
declare(strict_types=1);

$query = trim((string) ($_GET['q'] ?? ''));
$posts = [];
if (mb_strlen($query) >= 2) {
    $posts = mark_liked(search_posts($query), current_user());
}

$title = $query === '' ? 'Tìm kiếm' : 'Tìm: ' . $query;
$active = 'search';
require view('header');
?>
  <main class="feed">
    <h1 class="visually-hidden">Tìm kiếm</h1>
    <form class="search" method="get" action="<?= url('search') ?>" role="search">
      <label for="q" class="visually-hidden">Tìm bài viết</label>
      <input id="q" name="q" type="search" value="<?= e($query) ?>" placeholder="Tìm bài viết…" minlength="2" required>
      <button type="submit">Tìm</button>
    </form>

    <?php if ($query !== ''): ?>
      <p class="result-count" role="status"><?= count($posts) ?> kết quả cho “<?= e($query) ?>”</p>
    <?php endif; ?>
    <section aria-label="Kết quả">
      <?php foreach ($posts as $post): ?>
        <?php require view('post'); ?>
      <?php endforeach; ?>
    </section>
  </main>
<?php require view('footer'); ?>
