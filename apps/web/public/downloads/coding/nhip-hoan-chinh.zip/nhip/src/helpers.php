<?php
declare(strict_types=1);

date_default_timezone_set('Asia/Ho_Chi_Minh');

const MAX_LENGTH = 500;

/** In chữ ra HTML an toàn: < > & " ' thành thực thể, không bao giờ chạy như mã. */
function e(?string $text): string
{
    return htmlspecialchars($text ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** "3 phút trước", "2 giờ trước" — cùng ý với timeAgo() ở chặng 1. */
function time_ago(string $datetime): string
{
    $seconds = time() - strtotime($datetime);
    if ($seconds < 60) {
        return 'vừa xong';
    }
    if ($seconds < 3600) {
        return intdiv($seconds, 60) . ' phút trước';
    }
    if ($seconds < 86400) {
        return intdiv($seconds, 3600) . ' giờ trước';
    }
    return date('d/m/Y', strtotime($datetime));
}

/** Kiểm tra nội dung bài: trả chuỗi lỗi, hoặc null nếu hợp lệ. */
function check_post(string $body): ?string
{
    $body = trim($body);
    if ($body === '') {
        return 'Hãy viết gì đó.';
    }
    if (mb_strlen($body) > MAX_LENGTH) {
        return 'Tối đa ' . MAX_LENGTH . ' ký tự.';
    }
    return null;
}

/** Chuyển hướng rồi dừng hẳn — không để mã phía dưới chạy tiếp. */
function redirect(string $url): never
{
    header('Location: ' . $url, true, 303);
    exit;
}

/** Lời nhắn hiện một lần ở trang kế tiếp (sau khi chuyển hướng). */
function flash(?string $message = null): ?string
{
    if ($message !== null) {
        $_SESSION['flash'] = $message;
        return null;
    }
    $message = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $message;
}

/** Dừng với một trang lỗi gọn: 403 không có quyền, 404 không tìm thấy… */
function abort(int $status, string $message): never
{
    http_response_code($status);
    $title = (string) $status;
    $active = '';
    require __DIR__ . '/header.php';
    echo '<main class="feed"><p class="empty">' . e($message) . '</p></main>';
    require __DIR__ . '/footer.php';
    exit;
}

/** Đọc id dạng số nguyên dương từ $_GET hoặc $_POST; sai dạng thì 404. */
function id_param(array $source, string $key = 'id'): int
{
    $id = filter_var($source[$key] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    if ($id === false) {
        abort(404, 'Không tìm thấy.');
    }
    return $id;
}

/** Đường dẫn tới một view trong src/views/. Dùng: require view('header'); */
function view(string $name): string
{
    return __DIR__ . '/views/' . $name . '.php';
}

/** URL ảnh đại diện (mặc định ảnh chung) — đã tính base_path. */
function avatar_url(array $row): string
{
    return asset($row['avatar'] ?? 'img/avatar.svg');
}
