<?php
declare(strict_types=1);

/** Tạo một thông báo. Bỏ qua nếu tự gây cho chính mình (tự thích bài mình…). */
function notify(int $userId, int $actorId, string $type, ?int $postId = null): void
{
    if ($userId === $actorId) {
        return;
    }
    db()->prepare('INSERT INTO notifications (user_id, actor_id, type, post_id) VALUES (?, ?, ?, ?)')
        ->execute([$userId, $actorId, $type, $postId]);
}

/** Số thông báo chưa đọc — cho huy hiệu trên thanh điều hướng. */
function unread_count(int $userId): int
{
    $stmt = db()->prepare('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0');
    $stmt->execute([$userId]);
    return (int) $stmt->fetchColumn();
}

/** Danh sách thông báo kèm tên người gây ra. */
function notifications_for(int $userId, int $limit = 30): array
{
    $stmt = db()->prepare('
        SELECT n.id, n.type, n.post_id, n.is_read, n.created_at,
               u.username AS actor_name, u.display_name AS actor_display, u.avatar AS actor_avatar
        FROM notifications AS n
        JOIN users AS u ON u.id = n.actor_id
        WHERE n.user_id = :uid
        ORDER BY n.created_at DESC
        LIMIT :limit');
    $stmt->bindValue(':uid', $userId, PDO::PARAM_INT);
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

function mark_notifications_read(int $userId): void
{
    db()->prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0')->execute([$userId]);
}

/** Gửi thông báo "nhắc tên" cho các @username có thật (trừ chính tác giả). */
function notify_mentions(string $body, int $authorId, ?int $postId): void
{
    foreach (extract_mentions($body) as $username) {
        $user = find_user_by_username($username);
        if ($user !== null) {
            notify((int) $user['id'], $authorId, 'mention', $postId);
        }
    }
}
