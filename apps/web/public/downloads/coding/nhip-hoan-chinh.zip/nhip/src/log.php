<?php
declare(strict_types=1);

/** Địa chỉ IP người gọi, dạng nhị phân gọn (hỗ trợ cả IPv4 lẫn IPv6). */
function client_ip(): ?string
{
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $packed = @inet_pton($ip);
    return $packed === false ? null : $packed;
}

/** Ghi một thao tác nhạy cảm vào nhật ký. Không bao giờ ghi mật khẩu hay token. */
function log_action(string $action, ?int $userId = null, string $detail = ''): void
{
    db()->prepare('INSERT INTO activity_log (user_id, action, detail, ip) VALUES (?, ?, ?, ?)')
        ->execute([$userId, $action, mb_substr($detail, 0, 255), client_ip()]);
}
