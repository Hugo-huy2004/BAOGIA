<?php
declare(strict_types=1);

$me = require_login();
$displayName = $me['display_name'];
$bio = $me['bio'];
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $displayName = trim((string) ($_POST['display_name'] ?? ''));
    $bio = trim((string) ($_POST['bio'] ?? ''));

    if (mb_strlen($displayName) < 1 || mb_strlen($displayName) > 60) {
        $errors['display_name'] = 'Tên hiển thị 1–60 ký tự.';
    }
    if (mb_strlen($bio) > 160) {
        $errors['bio'] = 'Giới thiệu tối đa 160 ký tự.';
    }

    $avatar = $me['avatar'];
    $upload = $_FILES['avatar'] ?? null;
    if (!$errors && $upload && $upload['error'] !== UPLOAD_ERR_NO_FILE) {
        try {
            $avatar = save_avatar($upload);
        } catch (RuntimeException $e) {
            $errors['avatar'] = $e->getMessage();
        }
    }

    if (!$errors) {
        update_profile((int) $me['id'], $displayName, $bio, $avatar);
        if ($avatar !== $me['avatar']) {
            delete_avatar($me['avatar']);
        }
        flash('Đã cập nhật hồ sơ.');
        redirect(url('profile', ['username' => $me['username']]));
    }
}

$title = 'Sửa hồ sơ';
$active = 'profile';
require view('header');
?>
  <main class="auth">
    <h1>Sửa hồ sơ</h1>
    <form method="post" action="<?= url('settings.post') ?>" enctype="multipart/form-data">
        <?= csrf_field() ?>
      <div class="field avatar-field">
        <img class="avatar-lg" src="<?= e(avatar_url($me)) ?>" alt="Ảnh đại diện hiện tại" width="72" height="72">
        <div>
          <label for="avatar">Ảnh đại diện</label>
          <input id="avatar" name="avatar" type="file" accept="image/jpeg,image/png,image/webp">
          <p class="hint">JPG, PNG hoặc WebP, tối đa 2 MB.</p>
          <?php if (isset($errors['avatar'])): ?><p class="form-error"><?= e($errors['avatar']) ?></p><?php endif; ?>
        </div>
      </div>
      <div class="field">
        <label for="display_name">Tên hiển thị</label>
        <input id="display_name" name="display_name" value="<?= e($displayName) ?>" maxlength="60" required>
        <?php if (isset($errors['display_name'])): ?><p class="form-error"><?= e($errors['display_name']) ?></p><?php endif; ?>
      </div>
      <div class="field">
        <label for="bio">Giới thiệu</label>
        <textarea id="bio" name="bio" rows="3" maxlength="160"><?= e($bio) ?></textarea>
        <?php if (isset($errors['bio'])): ?><p class="form-error"><?= e($errors['bio']) ?></p><?php endif; ?>
      </div>
      <button type="submit" class="primary">Lưu hồ sơ</button>
    </form>
  </main>
<?php require view('footer'); ?>
