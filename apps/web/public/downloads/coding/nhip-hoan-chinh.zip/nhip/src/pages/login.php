<?php
declare(strict_types=1);

if (current_user()) {
    redirect(url('feed'));
}

$login = '';
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim((string) ($_POST['login'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');

    if (login_attempt_count() >= LOGIN_MAX_ATTEMPTS) {
        $error = 'Bạn đã thử sai quá nhiều lần. Hãy đợi ' . LOGIN_WINDOW_MIN . ' phút rồi thử lại.';
    } else {
        $userId = verify_login($login, $password);
        if ($userId === null) {
            record_login_attempt($login);
            log_action('login_failed', null, $login);
            // Không nói rõ sai tên hay sai mật khẩu.
            $error = 'Tên đăng nhập hoặc mật khẩu không đúng.';
        } else {
            clear_login_attempts();
            login_user($userId);
            log_action('login', $userId);
            redirect(url('feed'));
        }
    }
}

$title = 'Đăng nhập';
$active = 'login';
require view('header');
?>
  <main class="auth">
    <h1>Đăng nhập</h1>
    <form method="post" action="<?= url('login.post') ?>">
        <?= csrf_field() ?>
      <div class="field">
        <label for="login">Tên người dùng hoặc email</label>
        <input id="login" name="login" value="<?= e($login) ?>" required autocomplete="username">
      </div>
      <div class="field">
        <label for="password">Mật khẩu</label>
        <input id="password" name="password" type="password" required autocomplete="current-password">
      </div>
      <?php if ($error): ?>
        <p class="form-error" role="alert"><?= e($error) ?></p>
      <?php endif; ?>
      <button type="submit" class="primary">Đăng nhập</button>
    </form>
    <p>Chưa có tài khoản? <a href="<?= url('register') ?>">Đăng ký</a></p>
  </main>
<?php require view('footer'); ?>
