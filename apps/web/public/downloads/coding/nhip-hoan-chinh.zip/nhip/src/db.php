<?php
declare(strict_types=1);

/**
 * Kết nối PDO dùng chung cho cả yêu cầu. Gọi db() bao nhiêu lần cũng chỉ mở
 * MỘT kết nối (biến static giữ lại giữa các lần gọi).
 */
function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $config = require __DIR__ . '/../config.php';
        $dsn = "mysql:host={$config['db_host']};dbname={$config['db_name']};charset=utf8mb4";
        $pdo = new PDO($dsn, $config['db_user'], $config['db_pass'], [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,  // lỗi SQL thành ngoại lệ
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,        // mỗi dòng là mảng kết hợp
            PDO::ATTR_EMULATE_PREPARES   => false,                   // prepared statement thật
        ]);
    }
    return $pdo;
}
