<?php
declare(strict_types=1);

function is_following(int $followerId, int $followeeId): bool
{
    $stmt = db()->prepare('SELECT 1 FROM follows WHERE follower_id = ? AND followee_id = ?');
    $stmt->execute([$followerId, $followeeId]);
    return $stmt->fetchColumn() !== false;
}

/** Theo dõi. INSERT IGNORE: bấm hai lần không lỗi, khoá chính kép chặn trùng. */
function follow(int $followerId, int $followeeId): void
{
    if ($followerId === $followeeId) {
        return;                                  // CHECK trong bảng cũng chặn, nhưng đừng để lỗi tới đó
    }
    db()->prepare('INSERT IGNORE INTO follows (follower_id, followee_id) VALUES (?, ?)')
        ->execute([$followerId, $followeeId]);
}

function unfollow(int $followerId, int $followeeId): void
{
    db()->prepare('DELETE FROM follows WHERE follower_id = ? AND followee_id = ?')
        ->execute([$followerId, $followeeId]);
}

/** Bảng tin "Đang theo dõi": bài gốc của những người $userId theo dõi, cùng bài của chính mình. */
function following_feed(int $userId, int $limit = 20): array
{
    $stmt = db()->prepare(FEED_SQL . '
        WHERE p.parent_id IS NULL
          AND (p.user_id = :me OR p.user_id IN (SELECT followee_id FROM follows WHERE follower_id = :me2))
        GROUP BY p.id
        ORDER BY p.created_at DESC, p.id DESC
        LIMIT :limit');
    $stmt->bindValue(':me', $userId, PDO::PARAM_INT);
    $stmt->bindValue(':me2', $userId, PDO::PARAM_INT);
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}
