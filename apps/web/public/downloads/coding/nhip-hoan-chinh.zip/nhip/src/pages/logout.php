<?php
declare(strict_types=1);

// Chỉ nhận POST: một thẻ <img src="logout.php"> trên trang lạ không đăng xuất được bạn.
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Phương thức không được phép.');
}
logout_user();
redirect(url('feed'));
