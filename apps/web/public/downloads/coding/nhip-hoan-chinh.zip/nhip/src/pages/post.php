<?php
declare(strict_types=1);

$id = id_param(['id' => route_param('id')]);
$post = find_post($id);
if ($post === null) {
    abort(404, 'Bài này không còn tồn tại.');
}

$error = null;
$body = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $me = require_login();
    $body = (string) ($_POST['body'] ?? '');
    $error = check_post($body);
    if ($error === null) {
        $newId = publish_post((int) $me['id'], $body, $id);
        redirect(url('post', ['id' => $id]) . '#p' . $newId);
    }
}

$viewer = current_user();
[$post] = mark_liked([$post], $viewer);
$replies = reply_tree($id);

/** In cây trả lời: mỗi tầng một <ol> lồng trong tầng trên. */
function render_replies(array $nodes, ?array $viewer, int $depth = 1): void
{
    if (!$nodes) {
        return;
    }
    echo '<ol class="replies depth-' . min($depth, 3) . '">';
    foreach (mark_liked($nodes, $viewer) as $post) {
        echo '<li id="p' . (int) $post['id'] . '">';
        require view('post');
        render_replies($post['children'], $viewer, $depth + 1);
        echo '</li>';
    }
    echo '</ol>';
}

$title = 'Bài của @' . $post['username'];
$active = '';
require view('header');
?>
  <main class="feed">
    <p><a href="<?= url('feed') ?>">← Bảng tin</a></p>
    <?php require view('post'); ?>

    <?php if ($viewer): ?>
      <form class="composer reply-composer" method="post" action="<?= url('post.reply', ['id' => $id]) ?>">
        <?= csrf_field() ?>
        <label for="body">Trả lời @<?= e($post['username']) ?></label>
        <textarea id="body" name="body" rows="2" maxlength="<?= MAX_LENGTH ?>" required><?= e($body) ?></textarea>
        <?php if ($error !== null): ?>
          <p class="form-error" role="alert"><?= e($error) ?></p>
        <?php endif; ?>
        <div class="composer-foot">
          <span><?= (int) $post['replies'] ?> câu trả lời</span>
          <button type="submit">Trả lời</button>
        </div>
      </form>
    <?php endif; ?>

    <section aria-label="Các câu trả lời">
      <?php render_replies($replies, $viewer); ?>
    </section>
  </main>
<?php require view('footer'); ?>
