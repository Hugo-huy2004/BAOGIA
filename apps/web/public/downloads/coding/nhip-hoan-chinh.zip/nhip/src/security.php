<?php
declare(strict_types=1);

/**
 * Tiêu đề bảo mật gửi kèm MỌI trang. Content-Security-Policy là lớp thứ hai
 * chống XSS: dù một chỗ nào đó quên e(), trình duyệt vẫn từ chối chạy mã
 * viết trong HTML (thẻ <script> nội tuyến, onerror=, onclick=…).
 */
function send_security_headers(): void
{
    header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self'; "
        . "img-src 'self' data:; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'");
    header('X-Content-Type-Options: nosniff');            // không đoán kiểu tệp
    header('Referrer-Policy: strict-origin-when-cross-origin');
}
