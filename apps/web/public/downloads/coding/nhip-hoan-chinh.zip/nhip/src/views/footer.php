  <footer class="site-foot">Nhịp · dự án học tập của khoá Coding</footer>
  <script src="<?= asset('js/app.js') ?>" defer></script>
</body>
</html>
