<?php
declare(strict_types=1);

/**
 * Chống CSRF theo mẫu "đồng bộ token": mỗi phiên có một token bí mật. Mọi
 * biểu mẫu POST nhúng token đó; máy chủ chỉ chấp nhận yêu cầu mang đúng token.
 * Trang lạ không đọc được token (khác nguồn) nên không giả mạo được yêu cầu.
 */
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

/** Ô ẩn nhúng vào mỗi biểu mẫu POST. */
function csrf_field(): string
{
    return '<input type="hidden" name="_token" value="' . e(csrf_token()) . '">';
}

/**
 * Chặn mọi POST không mang đúng token. Gọi ngay đầu bootstrap, sau khi mở phiên.
 * hash_equals so sánh thời gian cố định để không lộ token qua đo thời gian.
 */
function csrf_check(): void
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        return;
    }
    $sent = (string) ($_POST['_token'] ?? '');
    if ($sent === '' || !hash_equals(csrf_token(), $sent)) {
        abort(419, 'Phiên làm việc đã hết hạn hoặc yêu cầu không hợp lệ. Hãy tải lại trang và thử lại.');
    }
}
