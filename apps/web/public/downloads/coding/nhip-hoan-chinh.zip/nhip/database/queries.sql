-- Các truy vấn của Nhịp (step 10). Chạy từng khối trong tab SQL của nhip.

-- 1. Bảng tin: bài gốc mới nhất, kèm tác giả và số tim.
SELECT p.id, u.username, u.display_name, p.body, p.created_at,
       COUNT(l.user_id) AS likes
FROM posts AS p
JOIN users AS u ON u.id = p.user_id
LEFT JOIN likes AS l ON l.post_id = p.id
WHERE p.parent_id IS NULL
GROUP BY p.id, u.username, u.display_name, p.body, p.created_at
ORDER BY p.created_at DESC
LIMIT 20;

-- 2. Trang cá nhân: thông tin + số người theo dõi / đang theo dõi.
SELECT u.id, u.username, u.display_name, u.bio,
       (SELECT COUNT(*) FROM follows WHERE followee_id = u.id) AS followers,
       (SELECT COUNT(*) FROM follows WHERE follower_id = u.id) AS following
FROM users AS u
WHERE u.username = 'lan.code';

-- 3. Các câu trả lời của bài 5, cũ nhất trước.
SELECT p.id, u.username, p.body, p.created_at
FROM posts AS p
JOIN users AS u ON u.id = p.user_id
WHERE p.parent_id = 5
ORDER BY p.created_at ASC;

-- 4. Ai đăng nhiều bài gốc nhất (ít nhất 2 bài).
SELECT u.username, COUNT(*) AS post_count
FROM posts AS p
JOIN users AS u ON u.id = p.user_id
WHERE p.parent_id IS NULL
GROUP BY u.username
HAVING COUNT(*) >= 2
ORDER BY post_count DESC;

-- 5. Bảng tin "Đang theo dõi" của lan.code (user 1): bài của người Lan theo dõi.
SELECT p.id, u.username, p.body, p.created_at
FROM posts AS p
JOIN users AS u ON u.id = p.user_id
WHERE p.parent_id IS NULL
  AND p.user_id IN (SELECT followee_id FROM follows WHERE follower_id = 1)
ORDER BY p.created_at DESC;

-- 6. Phân trang: trang 2, mỗi trang 3 bài.
SELECT id, body FROM posts
WHERE parent_id IS NULL
ORDER BY created_at DESC, id DESC
LIMIT 3 OFFSET 3;

-- 7. Sửa bài: CHỈ khi đúng chủ bài. Luôn có WHERE.
UPDATE posts
SET body = 'Box model: content → padding → border → margin.', updated_at = NOW()
WHERE id = 3 AND user_id = 1;

-- 8. Bỏ tim.
DELETE FROM likes WHERE user_id = 2 AND post_id = 1;
