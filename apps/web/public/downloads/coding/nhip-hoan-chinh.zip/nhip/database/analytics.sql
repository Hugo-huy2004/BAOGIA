-- Truy vấn phân tích của Nhịp (step 23). Chạy trong tab SQL của nhip.

-- 1. Chỉ số tổng quan.
SELECT
  (SELECT COUNT(*) FROM users)                         AS tong_nguoi_dung,
  (SELECT COUNT(*) FROM posts WHERE parent_id IS NULL) AS tong_bai_goc,
  (SELECT COUNT(*) FROM posts WHERE parent_id IS NOT NULL) AS tong_tra_loi,
  (SELECT COUNT(*) FROM likes)                         AS tong_tim,
  (SELECT COUNT(*) FROM follows)                       AS tong_theo_doi;

-- 2. Bài mới theo ngày (7 ngày gần nhất).
SELECT DATE(created_at) AS ngay, COUNT(*) AS so_bai
FROM posts
WHERE created_at > (NOW() - INTERVAL 7 DAY)
GROUP BY DATE(created_at)
ORDER BY ngay;

-- 3. Người dùng hoạt động theo ngày (DAU: có đăng ít nhất 1 bài).
SELECT DATE(created_at) AS ngay, COUNT(DISTINCT user_id) AS nguoi_dang_bai
FROM posts
WHERE created_at > (NOW() - INTERVAL 7 DAY)
GROUP BY DATE(created_at)
ORDER BY ngay;

-- 4. Top 5 người đăng nhiều bài gốc nhất.
SELECT u.username, COUNT(*) AS so_bai
FROM posts AS p JOIN users AS u ON u.id = p.user_id
WHERE p.parent_id IS NULL
GROUP BY u.id
ORDER BY so_bai DESC
LIMIT 5;

-- 5. 5 bài được thích nhiều nhất.
SELECT p.id, LEFT(p.body, 40) AS trich, COUNT(l.user_id) AS so_tim
FROM posts AS p LEFT JOIN likes AS l ON l.post_id = p.id
WHERE p.parent_id IS NULL
GROUP BY p.id
ORDER BY so_tim DESC
LIMIT 5;

-- 6. Tỷ lệ tương tác: trung bình số tim trên mỗi bài gốc.
SELECT ROUND((SELECT COUNT(*) FROM likes) / NULLIF((SELECT COUNT(*) FROM posts WHERE parent_id IS NULL), 0), 2)
       AS tim_trung_binh_moi_bai;

-- 7. An ninh: số lần đăng nhập sai theo ngày (từ nhật ký).
SELECT DATE(created_at) AS ngay, COUNT(*) AS lan_sai
FROM activity_log
WHERE action = 'login_failed' AND created_at > (NOW() - INTERVAL 7 DAY)
GROUP BY DATE(created_at)
ORDER BY ngay;
