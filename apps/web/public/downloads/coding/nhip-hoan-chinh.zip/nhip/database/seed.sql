-- Dữ liệu mẫu cho Nhịp (step 10). Chạy SAU schema.sql, trên cơ sở dữ liệu trống.
-- Mọi tài khoản mẫu có cùng mật khẩu: nhip-demo-2026 (chỉ dùng trên localhost).
USE nhip;

INSERT INTO users (username, display_name, email, password_hash, bio) VALUES
  ('lan.code',   'Lan Nguyễn',  'lan@example.com',  '$2y$12$N5Wu3hqguk6TTH.jPPJivOQRthZmktD.s3.9PaR7vPoAsVb1oWh4G', 'Học Coding để tự làm mạng xã hội của mình.'),
  ('minh.dev',   'Minh Trần',   'minh@example.com', '$2y$12$N5Wu3hqguk6TTH.jPPJivOQRthZmktD.s3.9PaR7vPoAsVb1oWh4G', 'Front-end, thích CSS hơn cà phê.'),
  ('an.ui',      'An Phạm',     'an@example.com',   '$2y$12$N5Wu3hqguk6TTH.jPPJivOQRthZmktD.s3.9PaR7vPoAsVb1oWh4G', 'Thiết kế giao diện, mê màu pastel.'),
  ('khoa.data',  'Khoa Lê',     'khoa@example.com', '$2y$12$N5Wu3hqguk6TTH.jPPJivOQRthZmktD.s3.9PaR7vPoAsVb1oWh4G', 'SQL mỗi ngày.'),
  ('mai.sec',    'Mai Đỗ',      'mai@example.com',  '$2y$12$N5Wu3hqguk6TTH.jPPJivOQRthZmktD.s3.9PaR7vPoAsVb1oWh4G', 'Tìm lỗ hổng trước khi kẻ xấu tìm ra.');

-- Thời điểm tính lùi từ NOW() để bảng tin lúc nào cũng "mới".
INSERT INTO posts (user_id, parent_id, body, created_at) VALUES
  (1, NULL, 'Hôm nay mình bắt đầu học Coding!',                         NOW() - INTERVAL 3 DAY),
  (2, NULL, 'CSS flexbox cứu cả buổi chiều.',                          NOW() - INTERVAL 2 DAY),
  (1, NULL, 'Box model: content, padding, border, margin.',             NOW() - INTERVAL 30 HOUR),
  (3, NULL, 'Màu nhấn chỉ nên có một. Nhiều màu quá là hết nhấn.',     NOW() - INTERVAL 20 HOUR),
  (4, NULL, 'JOIN không đáng sợ: chỉ là ghép hai bảng theo một cột.',   NOW() - INTERVAL 9 HOUR),
  (2, 5,    'Đồng ý! LEFT JOIN mới là thứ hay quên.',                   NOW() - INTERVAL 8 HOUR),
  (5, NULL, 'Nhắc nhẹ: đừng bao giờ nối chuỗi vào câu SQL.',            NOW() - INTERVAL 5 HOUR),
  (1, 7,    'Ghi nhớ! Step 11 sẽ học prepared statement.',              NOW() - INTERVAL 4 HOUR),
  (4, 5,    'Ví dụ: đếm số tim của mỗi bài cần LEFT JOIN + GROUP BY.',  NOW() - INTERVAL 3 HOUR),
  (3, NULL, 'Ai có mẹo chọn font tiếng Việt đẹp không?',                NOW() - INTERVAL 2 HOUR),
  (1, NULL, 'Nhịp đã đọc dữ liệu từ MySQL rồi!',                        NOW() - INTERVAL 25 MINUTE);

INSERT INTO likes (user_id, post_id) VALUES
  (2, 1), (3, 1), (4, 1),
  (1, 2), (3, 2), (4, 2), (5, 2),
  (2, 3),
  (1, 5), (2, 5), (3, 5), (5, 5),
  (1, 7), (2, 7), (4, 7),
  (2, 11), (5, 11);

INSERT INTO follows (follower_id, followee_id) VALUES
  (1, 2), (1, 4), (1, 5),
  (2, 1), (2, 4),
  (3, 1), (3, 2),
  (4, 1), (4, 5),
  (5, 1);
