# Nhịp

> Mạng xã hội chia sẻ bài viết ngắn — dự án học tập của khoá **Coding** (Hugo Studio).

Nhịp cho phép đăng ký, đăng bài, trả lời lồng nhau, thả tim, theo dõi, gắn hashtag,
nhắc tên và nhận thông báo. Xây bằng **PHP thuần + MySQL**, không thư viện ngoài.

![Bảng tin Nhịp](docs/feed.png)

## Tính năng

- Tài khoản: đăng ký, đăng nhập (tên hoặc email), mật khẩu băm bcrypt.
- Bài đăng: tạo / sửa / xoá có kiểm quyền sở hữu.
- Tương tác: thả tim không tải lại trang (Fetch), trả lời lồng nhiều tầng.
- Mạng lưới: trang cá nhân, ảnh đại diện, theo dõi, bảng tin "Đang theo dõi".
- Khám phá: tìm kiếm, hashtag `#chủ-đề`, nhắc tên `@người`.
- Thông báo: reply / like / follow / mention, huy hiệu chưa đọc.
- Bảo mật: chống SQL Injection, XSS, CSRF; CSP; giới hạn tần suất; nhật ký.
- Vận hành: thống kê sản phẩm (`/stats`), phân trang keyset.

## Yêu cầu

- PHP 8.2+ (có các tiện ích `pdo_mysql`, `gd`, `mbstring`, `fileinfo`).
- MySQL 8 hoặc MariaDB 10.4+.
- Máy chủ web (Apache + mod_rewrite, hoặc PHP built-in server khi phát triển).

## Cài đặt (localhost)

```bash
# 1. Lấy mã
git clone <repo> nhip && cd nhip

# 2. Cấu hình
cp config.sample.php config.php
# sửa config.php: db_host, db_name, db_user, db_pass

# 3. Tạo cơ sở dữ liệu
mysql -u root -e "SOURCE database/schema.sql"
mysql -u root nhip -e "SOURCE database/seed.sql"   # dữ liệu mẫu (tuỳ chọn)

# 4. Chạy (phát triển)
php -S localhost:8000 -t public public/router-dev.php
```

Mở http://localhost:8000. Tài khoản mẫu: `lan.code` / `nhip-demo-2026`.

Với XAMPP: chép thư mục vào `htdocs/`, trỏ trình duyệt tới
`http://localhost/nhip/public/`.

## Cấu trúc thư mục

```
nhip/
├── public/        web root: front controller + tài nguyên tĩnh
├── src/           mã nguồn: Model, View, Controller, router
│   ├── pages/     controller mỗi tuyến
│   └── views/     header, footer, thẻ bài
├── database/      schema.sql, seed.sql, analytics.sql
├── config.php     bí mật (KHÔNG commit)
├── DEPLOY.md      hướng dẫn đưa lên hosting
└── SECURITY.md    mô hình mối đe doạ
```

## Triển khai

Xem [DEPLOY.md](DEPLOY.md) để đưa Nhịp lên hosting miễn phí (PHP + MySQL + HTTPS).

## Bảo mật

Xem [SECURITY.md](SECURITY.md). Phát hiện lỗ hổng? Báo riêng cho người phụ trách,
không khai thác, không công khai trước khi được vá.

## Giấy phép

Dự án học tập. Độc quyền bởi Hugo Studio.
