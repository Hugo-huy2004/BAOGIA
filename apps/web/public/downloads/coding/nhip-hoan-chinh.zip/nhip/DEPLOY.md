# Triển khai Nhịp lên hosting miễn phí

Hướng dẫn đưa Nhịp lên một máy chủ chia sẻ (shared hosting) miễn phí có PHP + MySQL
(ví dụ InfinityFree). Nguyên tắc chung giống mọi hosting cPanel.

## 0. Trước khi lên

- [ ] Chạy lại `database/schema.sql` trên cơ sở dữ liệu trống để chắc nó đủ và đúng.
- [ ] Xoá thư mục `lab/` nếu còn (mã có lỗ hổng, step 17).
- [ ] Trong `config.php`: đặt `'debug' => false` (step 19).
- [ ] Trong `src/auth.php`: bật `'secure' => true` cho cookie phiên (chỉ gửi qua HTTPS).

## 1. Tạo tài khoản và website

1. Đăng ký tại hosting (chỉ cần email, không cần thẻ).
2. Tạo một website với **tên miền phụ miễn phí** (ví dụ `nhip.infinityfreeapp.com`).
3. Bật **SSL miễn phí** (Let's Encrypt) cho tên miền — để có HTTPS.

## 2. Tạo cơ sở dữ liệu MySQL

1. Trong bảng điều khiển → **MySQL Databases** → tạo một CSDL.
2. Ghi lại: **host** (không phải localhost!), **tên CSDL**, **user**, **mật khẩu**.
3. Mở **phpMyAdmin** của hosting → chọn CSDL → tab **Import** → tải lên `database/schema.sql`.
   (Có thể nạp thêm `database/seed.sql` nếu muốn dữ liệu mẫu.)

## 3. Tải mã lên

1. Lấy thông tin **FTP** trong bảng điều khiển (hoặc dùng File Manager).
2. Thư mục gốc web của hosting thường là `htdocs/` hoặc `public_html/`.
3. Tải **nội dung thư mục `public/`** vào thư mục gốc đó.
4. Tải `src/`, `config.php`, `database/` vào **thư mục CHA** của thư mục gốc
   (ngoài vùng web). Nếu hosting không cho ra ngoài web root, đặt chúng trong
   một thư mục và chặn truy cập bằng `.htaccess` (`Require all denied`).
5. Sửa `public/index.php` nếu cần để trỏ đúng đường dẫn tới `src/bootstrap.php`.

## 4. Cập nhật config.php trên hosting

```php
return [
    'db_host' => 'sqlXXX.infinityfree.com',   // host CSDL của hosting, KHÔNG phải 127.0.0.1
    'db_name' => 'if0_xxxxx_nhip',
    'db_user' => 'if0_xxxxx',
    'db_pass' => '••••••••',
    'debug'   => false,
];
```

## 5. Kiểm tra sau khi lên

- [ ] Mở `https://<tên-miền>/` — bảng tin hiện ra.
- [ ] Đăng ký một tài khoản, đăng bài, thả tim, theo dõi.
- [ ] Mở `https://<tên-miền>/config.php` → phải **404/403** (nằm ngoài web root).
- [ ] Tải lại bằng HTTPS, kiểm cookie có cờ **Secure**.
- [ ] Gây một lỗi → thấy trang 500 chung, KHÔNG lộ đường dẫn (debug=false).

## Giới hạn của hosting miễn phí

- Giới hạn CPU/RAM/truy vấn mỗi ngày — phù hợp học và demo, không cho tải lớn.
- Thường **không** cho chạy tiến trình nền, cron dày, hay gửi email tuỳ ý.
- Có thể ngừng site nếu vi phạm điều khoản. Dữ liệu quan trọng phải **tự sao lưu**
  định kỳ (phpMyAdmin → Export).
