<?php
// CHỈ dùng với máy chủ PHP built-in khi PHÁT TRIỂN:
//   php -S localhost:8000 -t public public/router-dev.php
// Nó mô phỏng .htaccess: tệp tĩnh có thật thì phục vụ, còn lại về index.php.
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
if ($path !== '/' && is_file(__DIR__ . $path)) {
    return false;
}
require __DIR__ . '/index.php';
