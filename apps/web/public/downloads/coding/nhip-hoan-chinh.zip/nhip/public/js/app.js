// Hỏi lại trước khi gửi những biểu mẫu nguy hiểm (xoá bài…).
// Gắn một lần cho cả trang nhờ sự kiện submit nổi bọt — giống step 6.
document.addEventListener("submit", (event) => {
  const message = event.target.dataset.confirm;
  if (message && !window.confirm(message)) {
    event.preventDefault();
  }
});

// Thả tim không tải lại trang: chặn biểu mẫu, gửi bằng fetch, vẽ lại từ JSON.
// Không có JavaScript thì biểu mẫu vẫn gửi bình thường (like.php chuyển hướng).
document.addEventListener("submit", async (event) => {
  const form = event.target.closest(".like-form");
  if (!form) return;
  event.preventDefault();

  const button = form.querySelector(".like");
  button.disabled = true;                       // chặn bấm đúp khi đang chờ
  try {
    const response = await fetch(form.action, {
      method: "POST",
      body: new FormData(form),
      headers: { Accept: "application/json" },
    });
    const data = await response.json();
    if (!response.ok) {
      if (response.status === 401) window.location.href = document.body.dataset.base + "/login";
      return;
    }
    button.setAttribute("aria-pressed", String(data.liked));
    button.querySelector(".visually-hidden").textContent = data.liked ? "Bỏ thích," : "Thích,";
    button.querySelector("span:last-child").textContent = data.likes;
  } catch {
    form.submit();                              // mạng lỗi: thử cách không JavaScript
  } finally {
    button.disabled = false;
  }
});
