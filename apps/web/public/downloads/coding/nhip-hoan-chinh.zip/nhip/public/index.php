<?php
// Front controller: MỌI yêu cầu (trừ tệp tĩnh) đi qua đây nhờ .htaccess.
declare(strict_types=1);

require __DIR__ . '/../src/bootstrap.php';
dispatch();
