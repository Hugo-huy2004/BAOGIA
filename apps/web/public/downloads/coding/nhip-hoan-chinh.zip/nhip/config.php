<?php
// Chép tệp này thành config.php rồi điền thông tin thật.
// config.php KHÔNG được đưa lên Git (step 20) — nó chứa mật khẩu.
return [
    'db_host' => '127.0.0.1',
    'db_name' => 'nhip',
    'db_user' => 'root',
    'db_pass' => '',
    'debug'   => true,     // true: hiện lỗi chi tiết. Trên hosting: false.
];
