# Mô hình mối đe doạ của Nhịp

Phiên bản: chặng 4, step 16. Cập nhật mỗi khi thêm tính năng có nhận dữ liệu từ người dùng.

## 1. Tài sản cần bảo vệ

| Tài sản | Vì sao quý | Thuộc tính cần giữ (CIA) |
|---|---|---|
| Băm mật khẩu (`users.password_hash`) | Lộ ra là bị dò mật khẩu ngoại tuyến | Bí mật |
| Email người dùng | Thông tin cá nhân | Bí mật |
| Mã phiên (cookie `nhip_session`) | Cầm được là mạo danh được | Bí mật, toàn vẹn |
| Bài đăng, tim, quan hệ theo dõi | Nội dung và danh tiếng của người dùng | Toàn vẹn, sẵn sàng |
| Ảnh đại diện tải lên | Có thể bị lợi dụng để chạy mã | Toàn vẹn |
| `includes/config.php` | Chứa tài khoản cơ sở dữ liệu | Bí mật |

## 2. Ranh giới tin cậy

1. Trình duyệt ↔ Apache: mọi thứ đi qua đây là **không tin được** (`$_GET`, `$_POST`, `$_FILES`, `$_COOKIE`, tiêu đề HTTP).
2. PHP ↔ MySQL: chỉ PHP được nói chuyện với MySQL, và chỉ qua prepared statement.
3. PHP ↔ hệ thống tệp: chỉ `uploads/avatars/` được ghi.

## 3. Điểm vào (bề mặt tấn công)

| Điểm vào | Phương thức | Dữ liệu nhận | Cần đăng nhập |
|---|---|---|---|
| `register.php` | POST | username, display_name, email, password | Không |
| `login.php` | POST | login, password | Không |
| `logout.php` | POST | — | Có |
| `index.php` | GET, POST | tab, body | POST: có |
| `post.php` | GET, POST | id, body | POST: có |
| `edit.php` | GET, POST | id, body | Có, đúng chủ bài |
| `delete.php` | POST | id | Có, đúng chủ bài |
| `like.php` | POST | post_id | Có |
| `follow.php` | POST | user_id, action | Có |
| `settings.php` | POST | display_name, bio, avatar (tệp) | Có |
| `profile.php` | GET | u | Không |
| `search.php` | GET | q | Không |

## 4. STRIDE

| Mối đe doạ | Ví dụ trên Nhịp | Biện pháp | Step |
|---|---|---|---|
| **S**poofing — mạo danh | Đánh cắp cookie phiên, dò mật khẩu | HttpOnly, đổi mã phiên, băm bcrypt, giới hạn số lần đăng nhập | 12, 18, 19 |
| **T**ampering — sửa trái phép | Sửa `id` để sửa bài người khác; SQL Injection | Kiểm chủ sở hữu trong SQL, prepared statement | 13, 17 |
| **R**epudiation — chối bỏ | "Tôi không xoá bài đó" | Nhật ký thao tác | 19 |
| **I**nformation disclosure — lộ thông tin | Trang lỗi lộ đường dẫn, tệp cấu hình đọc được | `debug = false`, chặn thư mục nhạy cảm | 19, 24 |
| **D**enial of service — từ chối dịch vụ | Gửi hàng nghìn bài/giây, tải tệp khổng lồ | Giới hạn tần suất, giới hạn dung lượng | 14, 19 |
| **E**levation of privilege — leo quyền | Tệp `.php` tải lên rồi chạy; XSS chiếm phiên quản trị | Kiểm nội dung tệp, `.htaccess`, `e()`, CSP | 14, 17, 18 |

## 5. Rủi ro còn mở (cần xử lý ở chặng 4)

- [ ] Biểu mẫu POST chưa có mã chống CSRF (step 18).
- [ ] Chưa có tiêu đề bảo mật (CSP, X-Content-Type-Options…) (step 18).
- [ ] Đăng nhập chưa giới hạn số lần thử (step 19).
- [ ] Chưa có nhật ký thao tác nhạy cảm (step 19).
- [ ] Lỗi PHP hiện chi tiết ra trình duyệt khi `debug = true` (step 19).

## 6. Báo cáo lỗ hổng

Phát hiện lỗ hổng trong Nhịp? Gửi mô tả và các bước tái hiện cho người phụ trách dự án. Không thử tấn công tài khoản hay dữ liệu của người khác.
